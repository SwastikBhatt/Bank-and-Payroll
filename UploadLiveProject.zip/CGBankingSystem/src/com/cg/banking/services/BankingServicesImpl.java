package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices{
	AccountDAOImpl accObj=new AccountDAOImpl();
	TransactionDAOImpl transData=new TransactionDAOImpl();
	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account=new Account(initBalance, accountType);
		account=accObj.save(account);
		return account;
	}

	@Override
	public float depositAmount(int accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account customer=null;
		customer=accObj.findOne(accountNo);
		if(customer==null)
			throw new AccountNotFoundException();
		else if(customer.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		customer.setAccountBalance(customer.getAccountBalance()+amount);
		transData.save(accountNo, new Transaction(amount, "Deposit"));
		return customer.getAccountBalance();
	}

	@Override
	public float withdrawAmount(int accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account customer=null;
		customer=accObj.findOne(accountNo);
		if(customer==null)
			throw new AccountNotFoundException();
		else if(customer.getPinNo()!=pinNumber)
			throw new InvalidPinNumberException();
		else if(customer.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else if(customer.getAccountBalance()-amount<500)
			throw new InsufficientAmountException();
		customer.setAccountBalance(customer.getAccountBalance()-amount);
		transData.save(accountNo, new Transaction(amount, "Withdraw"));
		return customer.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(int accountNoTo, int accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerTo=null,customerFrom=null;
		customerTo=accObj.findOne(accountNoTo);
		customerFrom=accObj.findOne(accountNoFrom);
		if(customerTo==null)
			throw new AccountNotFoundException();
		else if(customerFrom.getPinNo()!=pinNumber)
			throw new InvalidPinNumberException();
		else if(customerTo.getAccountStatus().equalsIgnoreCase("Blocked")|| customerFrom.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else
		{
			customerTo.setAccountBalance(customerTo.getAccountBalance()+transferAmount);
			transData.save(customerTo.getAccountNo(), new Transaction(transferAmount, "Deposit"));
			customerFrom.setAccountBalance(customerFrom.getAccountBalance()-transferAmount);
			transData.save(customerFrom.getAccountNo(), new Transaction(transferAmount, "Withdraw"));
			return true;
		}
	}

	@Override
	public Account getAccountDetails(int accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=accObj.findOne(accountNo);
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		List<Account> allDetails=accObj.findAll();
		return allDetails;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		
		return null;
	}

	@Override
	public String accountStatus(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account customer=null;
		customer=accObj.findOne(accountNo);
		if(customer==null)
			throw new AccountNotFoundException();
		else if(customer.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else
			return "Active";
	}

}
