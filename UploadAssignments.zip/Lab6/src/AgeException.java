
public class AgeException extends Exception
{
	public AgeException()
	{
		System.out.println("Age is less than 15");
	}

}
