
public class Employee 
{
	private int eId;
	private String eName;
	private float eSalary;
	private Gender eGender;
	public Employee(){}
	public int geteId() 
	{
		return eId;
	}
	public void seteId(int eId)
	{
		this.eId = eId;
	}
	public String geteName() 
	{
		return eName;
	}
	public void seteName(String eName)
	{
		this.eName = eName;
	}
	public float geteSalary() 
	{
		return eSalary;
	}
	public void seteSalary(float eSalary)
	{
		this.eSalary = eSalary;
	}
	public Gender geteGender() 
	{
		return eGender;
	}
	public void seteGender(Gender eGender)
	{
		this.eGender = eGender;
	}
	
}
