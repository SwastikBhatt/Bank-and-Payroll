/*package com.cg.banking.test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingDBUtil;


public class BankingServiceTest {
	private static BankingServices services;
	@BeforeClass
	public static void setUpTestEnv(){
		services=new BankingServicesImpl();
	}
	@Before
	public void setUpTestData(){
		Account account1=new Account(10001, "Savings", "Active", 10000);
		Account account2=new Account(10002, "Savings", "Blocked", 9000);
		BankingDBUtil.customer.put(account1.getAccountNo(), account1);
		BankingDBUtil.customer.put(account2.getAccountNo(), account2);
		BankingDBUtil.ACCOUNT_NUMBER=10003;
	}
	@Test
	public void testDepositAmountForValidAccountId() throws AccountNotFoundException {
		Account account1=new Account(10001, "Savings", "Active", 10000);
		account1.setAccountBalance(services.depositAmount(10001, 2000));
		int expectedAmount=(int)account1.getAccountBalance();
		int actualAmount=12000;
		Assert.assertEquals(actualAmount, actualAmount);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testDepositAmountForInvalidAccountId() throws AccountNotFoundException {
		services.depositAmount(1414, 21212);
	}
	@Test
	public void testWithdrawAmountForValidAccountId() throws AccountNotFoundException {
		Account account1=new Account(10001, "Savings", "Active", 10000);
		account1.setAccountBalance(services.withdrawAmount(10001, 2000,account1.getPinNo()));
		int expectedAmount=(int)account1.getAccountBalance();
		int actualAmount=8000;
		Assert.assertEquals(actualAmount, actualAmount);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testWithdrawAmountForValidAccountIdAndInvalidPin() throws InvalidPinNumberException {
		Account account1=new Account(10001, "Savings", "Active", 10000);
		account1.setAccountBalance(services.withdrawAmount(10001, 2000,123456));
		int expectedAmount=(int)account1.getAccountBalance();
		int actualAmount=8000;
		Assert.assertEquals(actualAmount, actualAmount);
	}
	@Test(expected=AccountNotFoundException.class )
	public void testWithdrawAmountForInvalidAccountIdAndInvalidPin() throws  AccountNotFoundException{
		Account account1=new Account(10001, "Savings", "Active", 10000);
		account1.setAccountBalance(services.withdrawAmount(10011, 2000,111111));
		int expectedAmount=(int)account1.getAccountBalance();
		int actualAmount=8000;
		Assert.assertEquals(actualAmount, actualAmount);
	}
	@Test(expected=AccountBlockedException.class )
	public void testWithdrawAmountForBlockedAccount() throws  AccountBlockedException{
		services.withdrawAmount(10002, 1000, 0);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsForInvalidAccountId() throws AccountNotFoundException {
		services.getAccountDetails(1212);
	}
	@Test()
	public void testGetAccountDetailsForValidAccountId() throws AccountNotFoundException {
		Assert.assertEquals(new Account(10001, "Savings", "Active", 10000),services.getAccountDetails(10001));

	}
	@Test()
	public void testAccountStatusForValidAccountId() throws AccountBlockedException {
		String expectedStatus="Active";
		Assert.assertEquals(expectedStatus, services.accountStatus(10001));
	}
	@Test
	public void testGetAllAccountDetails() {
		Account account1=new Account(10001, "Savings", "Active", 10000);
		Account account2=new Account(10002, "Savings", "Blocked", 9000);
		List<Account> expectedAccountList=new ArrayList<Account>();
		expectedAccountList.add(account1);
		expectedAccountList.add(account2);
		List<Account> actualArrayList=services.getAllAccountDetails();
		Assert.assertEquals(expectedAccountList, actualArrayList);
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}
}*/
