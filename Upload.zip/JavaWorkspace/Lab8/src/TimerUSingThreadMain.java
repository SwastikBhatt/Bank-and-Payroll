
public class TimerUSingThreadMain {
	public static void main(String args[]){
		System.out.println("Consider a timer of 5 seconds");
		System.out.println();
		Thread th= new Thread(new ThreadUsingTimer());
		th.start();
		try {
			th.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println();
		System.out.println("Timer finished");
	}
}
