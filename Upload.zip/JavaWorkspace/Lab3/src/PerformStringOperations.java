import java.util.Scanner;
public class PerformStringOperations 
{
	public static void performOperations(String s,int ch)
	{
		String ms="";
		switch(ch)
		{
			case 1:System.out.println("Concerned output is "+s+s);
				   break;
			case 2:for(int i=0;i<s.length();i++)
				   {
						if(i%2==0)
							ms=ms+'#';
						else
							ms=ms+s.charAt(i);
				   }
					System.out.println("Concerned output is "+ms);
					break;
			case 3:String w1="";
				   s=s.trim();
				   for(int i=0;i<s.length();i++)
				   {
						if(!w1.contains(String.valueOf(s.charAt(i))))
							w1+=String.valueOf(s.charAt(i));
			       }
				   System.out.println("Concerned output is  "+w1);
				   break;
			case 4:String w="";
				   for(int i=0;i<s.length();i++)
			   	   {
						if(i%2==0)
						{
							w=Character.toString(s.charAt(i));
							ms=ms+(w).toUpperCase();
						}
						else
							ms=ms+s.charAt(i);
			   	   }
				   System.out.println("Concerned output is "+ms);
				   break;
			default:System.out.println("Invalid Choice");
		}
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String");
		String s=sc.next();
		System.out.println("Enter choice: \n1:Add the same string \n2:Place # in odd places \n3:Remove repeats"
				+ " \n4:Make odd positions to upper case");
		int c=sc.nextInt();
		performOperations(s,c);
	}

}
