
public class WageEmp extends Employee
{
	int noOfHours;
	static int ratePerHours;
	static{
		ratePerHours=500;
	}
	public WageEmp()
	{
		
	}
	public WageEmp(int empId, String empName,float empBasicSal,int noOfHours)
	{
		this.empId=empId;
		this.empBasicSal=empBasicSal;
		this.noOfHours = noOfHours;
		this.empName=empName;
	}
	public String dispWageEmpInfo()
	{
		return "WageEmp info ["+super.displayEmpInfo()+" no of hours "
				+noOfHours+" ]";
	}
	public float calcWageEmpMonSal()
	{
		return empBasicSal+(noOfHours*ratePerHours*20);
	}
	public float calcWageEmpAnnualSal()
	{
		return calcWageEmpMonSal()*12;
	}
}
