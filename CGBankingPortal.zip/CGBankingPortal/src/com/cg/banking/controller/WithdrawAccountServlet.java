package com.cg.banking.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/WithdrawAccountServlet")
public class WithdrawAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BankingServices bankingServices;
	@Override
	public void destroy() {
		bankingServices=null;
	}

	@Override
	public void init() throws ServletException {
		bankingServices=BankingServicesImpl.getBanking();
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher requestDispatcher=null;
		int accountNo=Integer.parseInt(request.getParameter("accountNo"));
		int amount=Integer.parseInt(request.getParameter("amount"));
		int pinNo=Integer.parseInt(request.getParameter("pinNo"));
		Account account=bankingServices.getAccountDetails(accountNo);
		if(account==null) {
			requestDispatcher=request.getRequestDispatcher("withdrawAccount.jsp");
			request.setAttribute("error", "Missing Information");
			requestDispatcher.forward(request, response);
		}
		else {
		account.setAccountBalance(bankingServices.withdrawAmount(accountNo, amount, pinNo));
		request.setAttribute("account", account);
		request.getRequestDispatcher("withdrawAccountSuccess.jsp").forward(request, response);
		}
	}

}
