
public class Employee 
{
	private int empId;
	private String empName;
	private float empSal;
	public Employee(int empId,String empName,float empSal)
	{
		super();
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + "]";
	}
	public float calcEmpMonSal()
	{
		return empSal;
	}
	public float calcEmpAnnSal()
	{
		return empSal*12;
	}
}
