package com.cg.banking.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/TransferAccountServlet")
public class TransferAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BankingServices bankingServices;
	@Override
	public void destroy() {
		bankingServices=null;
	}

	@Override
	public void init() throws ServletException {
		bankingServices=BankingServicesImpl.getBanking();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher requestDispatcher=null;
		int accountNoTo=Integer.parseInt(request.getParameter("accountNoTo"));
		int accountNoFrom=Integer.parseInt(request.getParameter("accountNoFrom"));
		int amount=Integer.parseInt(request.getParameter("amount"));
		int pinNo=Integer.parseInt(request.getParameter("pinNo"));
		Account accountTo=bankingServices.getAccountDetails(accountNoTo);
		Account accountFrom=bankingServices.getAccountDetails(accountNoFrom);
		if(accountTo==null||accountFrom==null) {
			requestDispatcher=request.getRequestDispatcher("transferAccount.jsp");
			request.setAttribute("error", "Missing Information");
			requestDispatcher.forward(request, response);
		}
		else {
		bankingServices.fundTransfer(accountNoTo, accountNoFrom, amount, pinNo);
		accountFrom.setAccountBalance(accountFrom.getAccountBalance());
		request.setAttribute("account", accountFrom);
		request.getRequestDispatcher("transferAccountSucces.jsp").forward(request, response);
		}
	}

}
