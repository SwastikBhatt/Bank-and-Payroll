package com.cg.billing.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.billing.beans.Customer;


@Controller
public class URIController {
	
	Customer customer;
	
	@RequestMapping(value= {"/","index"})
	public String getIndexPage(){
		return "index";
	}
	
	@RequestMapping("/registration")
	public String getRegistrationPage() {
		return "registrationPage";
	}
	
	@RequestMapping("/openPostpaid")
	public String getPostpaidPage() {
		return "postpaidPage";
	}
	
	@RequestMapping("/findCustomerDetails")
	public String getfindCustomerDetailsPage() {
		return "findCustomerDetailsPage";
	}
	
	//findAllCustomerDetails
	@RequestMapping("/findAllCustomerDetails")
	public String getfindAllCustomerDetailsPage() {
		return "findAllCustomerDetailsPage";
	}
	//getPostpaidDetails
	
	@RequestMapping("/getPostpaidDetails")
	public String getPostpaidDetailsPage() {
		return "postpaidDetailsPage";
	}
	//findBillAmount
	@RequestMapping("/findBillAmount")
	public String findBillAmountPage() {
		return "findBillAmountPage";
	}
	@ModelAttribute
	public Customer getCustomer() {
		customer=new Customer();
		return customer;
	}
	
}
