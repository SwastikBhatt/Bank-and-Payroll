import static java.lang.Math.*;
class Calculator
{
	public int add(int ... nums)
	{
		int sum=0;
		for(int i=0;i<nums.length;i++)
			sum+=nums[i];
		return sum;
	}
	

}
public class TestJavaFeaturesDemo
{
	public static void main(String args[])
	{
		Calculator ob=new Calculator();
		System.out.println("Added value is "+ob.add(30,23,32,40));
		System.out.println("Value of pi="+Math.PI);
		System.out.println("Value of pi="+sqrt(2));
		
		System.out.println("***************enhanced for loop******************");
		int nums[]=new int[4];
		nums[0]=34;
		nums[1]=44;
		nums[2]=12;
		nums[3]=56;
		
		for(int temp:nums)
			System.out.println("  "+temp);
			
	}
}