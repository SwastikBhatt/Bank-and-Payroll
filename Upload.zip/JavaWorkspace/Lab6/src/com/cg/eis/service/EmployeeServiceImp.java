package com.cg.eis.service;

import java.util.Arrays;

import com.cg.eis.bean.Designation;
import com.cg.eis.bean.Employee;
import com.cg.eis.bean.Insurance;
import com.cg.eis.exception.EmployeeException;

public class EmployeeServiceImp implements EmployeeService
{
	private int noOfEmployees;
	private Employee empList[];
	
	public EmployeeServiceImp(int noOfEmployees) 
	{
		this.empList = new Employee[noOfEmployees];
	}

	public Insurance findEmployeeInsurance(double eSalary,
			Designation eDesignation) 
	{
		if(eSalary<5000)
			return Insurance.NoScheme;
		else if(eSalary>=5000 && eSalary<20000)
			return Insurance.SchemeC;
		else if(eSalary>=20000 && eSalary<40000)
			return Insurance.SchemeB;
		else if(eSalary>=40000)
			return Insurance.SchemeA;
		
		return null;
		
	}
	public String displayEmployeeDetails(int i) {
		return this.empList[i].toString();
	}

	@Override
	public void addEmployeeDetails(int i, long eId, String eName,
			double eSalary, Designation eDesignation, Insurance eInsuranceScheme) {
		if(i>=0 && i<this.empList.length)
			try {
				empList[i]=new Employee(eId,eName,eSalary,
eDesignation,eInsuranceScheme);
			} catch (EmployeeException e) {
			}
		
	}

	
	
		
	

}
