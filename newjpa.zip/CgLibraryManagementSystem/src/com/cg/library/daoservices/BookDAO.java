package com.cg.library.daoservices;

import java.util.List;
import com.cg.library.beans.Book;
import com.cg.library.exceptions.BookNotFoundException;

public interface BookDAO {
	public Book save(Book book);
	public Book findOne(int bookISBN);
	public boolean update(Book book);
	List<Book>findAll();
}
