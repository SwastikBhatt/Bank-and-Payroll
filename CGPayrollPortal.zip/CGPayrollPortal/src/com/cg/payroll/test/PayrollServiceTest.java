package com.cg.payroll.test;
/*package com.cg.payroll.test;


import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

public class PayrollServiceTest {
	private static PayrollServices services;
	@BeforeClass
	public static void setUpTestEnv(){
		services=new PayrollServicesImpl();
	}
	@Before
	public void setUpTestData(){
		Associate associate1=new Associate(101, 78000, "Swastik", "Bhattacharya", "Training", "A", "DAS315", "swastik@capgemini.com", new BankDetails(12345, "CITI", "12321"),new Salary(30000, 1800, 1800));
		Associate associate2=new Associate(102, 78000, "Saiyam", "Lunia", "Training", "A", "D6F315", "saiyam@capgemini.com", new BankDetails(84368, "CITI", "12321"),new Salary(30000, 1800, 1800));
		PayrollDBUtil.associates.put(associate1.getAssociateId(), associate1);
		PayrollDBUtil.associates.put(associate2.getAssociateId(), associate2);
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailsNotFoundException {
		services.getAssociateDetails(1234);
	}
	@Test
	public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailsNotFoundException {
		Assert.assertEquals(new Associate(101, 78000, "Swastik", "Bhattacharya", "Training", "A", "DAS315", "swastik@capgemini.com", new BankDetails(12345, "CITI", "12321"),new Salary(30000, 1800, 1800)),services.getAssociateDetails(101));
	}
	@Test
	public void testAcceptAssociateDetails() {
		Assert.assertEquals(103, services.acceptAssociateDetails("Swastik", "Bhattacharya", "swastik@capgemini.com", "Training", "A", "DAS315", 12000, 78000, 1200, 1200, 1234241, "CITI", "12321"));
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId()throws AssociateDetailsNotFoundException{
		services.calculateNetSalary(1431);
	}
	@Test
	public void testCalculateNetSalaryForValidAssociateId()throws AssociateDetailsNotFoundException{
		double expectedSalary=784800.0;
		double actualSalary=services.calculateNetSalary(102);
		Assert.assertEquals(expectedSalary, actualSalary, 0);
	}
	@Test
	public void testGetAllAssociateDetails() {
		Associate associate1=new Associate(101, 78000, "Swastik", "Bhattacharya", "Training", "A", "DAS315", "swastik@capgemini.com", new BankDetails(12345, "CITI", "12321"),new Salary(30000, 1800, 1800));
		Associate associate2=new Associate(102, 78000, "Saiyam", "Lunia", "Training", "A", "D6F315", "saiyam@capgemini.com", new BankDetails(84368, "CITI", "12321"),new Salary(30000, 1800, 1800));
		List<Associate> expectedAssociateList=new ArrayList<Associate>();
		expectedAssociateList.add(associate1);
		expectedAssociateList.add(associate2);
		List<Associate> actualArrayList=services.getAllAssociateDetails();
		Assert.assertEquals(expectedAssociateList, actualArrayList);
	}

	@After
	public void tearDownTesrData(){
		PayrollDBUtil.associates.clear();
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}
}*/
