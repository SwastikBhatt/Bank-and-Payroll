
public class TestStringDemo 
{
	public static void main(String args[])
	{
		String str1=new String("Capgemini");
		System.out.println("Hashcode of str1 = "+str1.hashCode());
		String str2=new String("Capgemini");
		System.out.println("Hashcode of str2 = "+str2.hashCode());
		String str3="Capgemini";
		System.out.println("Hashcode of str3 = "+str3.hashCode());
		String str4="Capgemini";
		System.out.println("Hashcode of str4 = "+str4.hashCode());
		StringBuffer str5=new StringBuffer("Capgemini");
		System.out.println("Hashcode of str5 = "+str5.hashCode());
		System.out.println("is str1==str3 "+(str1==str3));
		System.out.println("is str1==str2 "+(str1==str2));
		System.out.println("is str3==str4 "+(str3==str4));
		System.out.println("is str1.equals(str3) "+str1.equals(str3));
		System.out.println("is str1.equals(str2) "+str1.equals(str2));
		System.out.println("is str1.equals(str4) "+str1.equals(str4));
		
	}

}
