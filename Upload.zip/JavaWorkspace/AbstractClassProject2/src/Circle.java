
public class Circle extends Shape
{

	public Circle(int rad,String shapeType)
	{
		super(shapeType,rad);
	}

	@Override
	public float calcArea() 
	{
		return (float) (Math.PI*rad*rad);
	}
	public float calcCircumference()
	{
		return (float) (2*Math.PI*rad);
	}
}
