import java.util.Scanner;
public class TestEnumDemo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		Seasons currentSeason = null;
		System.out.println("Enter season Choice \n1:Summer\n2:Rainy\n3:Winter");
		int n=sc.nextInt();
		switch(n)
		{
			case 1:currentSeason=Seasons.Summer;
				   break;
			case 2:currentSeason=Seasons.Rainy;
			   	   break;
			case 3:currentSeason=Seasons.Winter;
			   	   break;
			default:System.out.println("Invalid Input");
		}
		System.out.println("Season Value is "+currentSeason);
	}
}
