public interface Printable 
{
	static String compName="Capgemini";
	String print();

}
