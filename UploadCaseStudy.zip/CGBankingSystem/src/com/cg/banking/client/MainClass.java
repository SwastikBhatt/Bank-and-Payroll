package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String args[]) {
		int accNo,c,p=0;
		int pinNo;
		float amount;
		Scanner sc=new Scanner(System.in);
		BankingServices bankingService= new BankingServicesImpl();
		Account c1=bankingService.openAccount("Savings", 2000);
		c1.setAccountStatus("Active");
		Account c2=bankingService.openAccount("Savings", 9000);
		c2.setAccountStatus("Active");
		Account c3=bankingService.openAccount("Savings", 4000);
		c3.setAccountStatus("Active");
		Account c4=bankingService.openAccount("Savings", 5000);
		c4.setAccountStatus("Active");
		while(true) {
			System.out.println("Account details\n"+c1);
			System.out.println("Account details\n"+c2);
			System.out.println("Account details\n"+c3);
			System.out.println("Account details\n"+c4);
			System.out.println("\n\nEnter a choice \n1:Withdraw \n2:Deposit \n3:Transfer \n4:Exit");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:
				System.out.println("*********************WITHDRAWAL**************************");
				System.out.println("Enter account number from which money is to be withdrawn");
				accNo=sc.nextInt();
				if(bankingService.getAccountDetails(accNo).getAccountStatus().equalsIgnoreCase("Blocked")) {
					System.out.println("Account has already been blocked");
					break;
				}
				else {
					c=0;
					do {
						if(c>0)
							System.out.println("Entered pin was wrong ");
						System.out.println("Enter pin number of that account");
						pinNo=sc.nextInt();
						c++;
						if(bankingService.getAccountDetails(accNo).getPinNo()==pinNo) 
							break;
						if(c==3 && bankingService.getAccountDetails(accNo).getPinNo()!=pinNo) {
							bankingService.getAccountDetails(accNo).setAccountStatus("Blocked");
							System.out.println("Multiple wrong pins have resulted in blocking of account");p=1;
							break;
						}
					}while(c<3);
					if(p==1)
						break;
					System.out.println("Enter amount of money to be withdrawn");
					amount=sc.nextInt();
					System.out.println(bankingService.withdrawAmount(accNo, amount, pinNo));
					break;
				}
			case 2:
				System.out.println("*********************DEPOSIT**************************");
				System.out.println("Enter account number to which money is to be deposited");
				accNo=sc.nextInt();
				if(bankingService.getAccountDetails(accNo).getAccountStatus().equalsIgnoreCase("Blocked")) {
					System.out.println("Account has already been blocked");
					break;
				}
				else {
					System.out.println("Enter amount of money to be deposited");
					amount=sc.nextInt();
					System.out.println(bankingService.depositAmount(accNo, amount));
					break;
				}
			case 3:
				System.out.println("*********************FUND TRANSFER**************************");
				System.out.println("Enter account number to which money is to be deposited");
				accNo=sc.nextInt();
				System.out.println("Enter account number from which money is to be transferred");
				int accNo2=sc.nextInt();
				c=0;
				if(bankingService.getAccountDetails(accNo).getAccountStatus().equalsIgnoreCase("Blocked")||bankingService.getAccountDetails(accNo2).getAccountStatus().equalsIgnoreCase("Blocked")) {
					System.out.println("Account has already been blocked");
					break;
				}
				else {
					c=0;
					do {
						if(c>0)
							System.out.println("Entered pin was wrong ");
						System.out.println("Enter pin number of that account");
						pinNo=sc.nextInt();
						c++;
						if(c==3 && bankingService.getAccountDetails(accNo2).getPinNo()!=pinNo) {
							bankingService.getAccountDetails(accNo).setAccountStatus("Blocked");
							System.out.println("Multiple wrong pins have resulted in blocking of account");p=1;
							break;
						}
						if(bankingService.getAccountDetails(accNo2).getPinNo()==pinNo) 
							break;
					}while(c<3);
					if(p==1)
						break;
					System.out.println("Enter amount of money to be deposited");
					amount=sc.nextInt();
					boolean b=bankingService.fundTransfer(accNo, accNo2, amount, pinNo);
					if(b==true)
						System.out.println("Transfer successful");
					break;
				}
			case 4:System.exit(0);
			default:System.out.println("You have entered a wrong choice please try again");
			}
		}
	}
}