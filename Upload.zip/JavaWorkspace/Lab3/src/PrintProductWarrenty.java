import java.time.LocalDate;
import java.util.Scanner;

public class PrintProductWarrenty 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter date of purchase in dd-mm-yyyy format");
		String s=sc.next();
		s=s+" ";
		System.out.println("Enter Expiration time in Months and years");
		long m=sc.nextLong();
		long y=sc.nextLong();
		int dd=Integer.parseInt(s.substring(0,2));
		int mm=Integer.parseInt(s.substring(3,5));
		int yyyy=Integer.parseInt(s.substring(6,10));
		LocalDate date1=LocalDate.of(yyyy, mm, dd);
		LocalDate wdate=date1.plusMonths(m);
		wdate=wdate.plusYears(y);
		System.out.println("Expiration date is "+wdate);
	}
}
