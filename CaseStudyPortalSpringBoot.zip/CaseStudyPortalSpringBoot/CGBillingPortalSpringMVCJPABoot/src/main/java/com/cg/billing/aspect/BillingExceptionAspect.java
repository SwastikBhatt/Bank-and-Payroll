package com.cg.billing.aspect;

public class BillingExceptionAspect {

}
