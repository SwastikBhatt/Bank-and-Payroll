
public class PersonV3Main 
{
	public static void main(String args[])
	{
		PersonV3 obj=new PersonV3("Swastik","Bhattacharya",Gender.M,25717938);
		System.out.println("First Name= "+obj.getFirstName());
		System.out.println("Last Name= "+obj.getLastName());
		System.out.println("Gender= "+obj.getGender());
		System.out.println("Phone Number= "+obj.getphNumber());	
	}
}
