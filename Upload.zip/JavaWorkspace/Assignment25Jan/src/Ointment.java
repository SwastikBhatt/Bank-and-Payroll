public class Ointment extends Medicine
{
	public void displayMedInfo()
	{
		System.out.println("For external use only");
		super.displayMedInfo();
	}

	public Ointment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Ointment(String medName, String compName, long medPrice) {
		super(medName, compName, medPrice);
		// TODO Auto-generated constructor stub
	}
}
