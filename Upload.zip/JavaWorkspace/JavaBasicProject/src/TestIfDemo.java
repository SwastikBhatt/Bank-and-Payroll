
public class TestIfDemo 
{
	public static void main(String[] args)
	{
		TestIfDemo ob=new TestIfDemo();
		int marks=78;
		if(marks<40)
			System.out.println(ob.getResult()+" Fail");
		else if(marks>=40 && marks<60)
			System.out.println(ob.getResult()+" Second Class");
		else if(marks>=60 && marks<75)
			System.out.println(ob.getResult()+" First Class");
		else
			System.out.println(ob.getResult()+" Distinction");
	}
	public String getResult()
	{
		return " You got: ";
	}
}
