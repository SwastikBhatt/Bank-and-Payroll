package com.cg.project.beans;

public class Date {
	int intday,intmonth,intyear;

	public Date(int intday, int intmonth, int intyear) {
		super();
		this.intday = intday;
		this.intmonth = intmonth;
		this.intyear = intyear;
	}

	public int getIntday() {
		return intday;
	}

	public void setIntday(int intday) {
		this.intday = intday;
	}

	public int getIntmonth() {
		return intmonth;
	}

	public void setIntmonth(int intmonth) {
		this.intmonth = intmonth;
	}

	public int getIntyear() {
		return intyear;
	}

	public void setIntyear(int intyear) {
		this.intyear = intyear;
	}

	@Override
	public String toString() {
		return "Date " + intday + " : " + intmonth
				+ " : " + intyear ;
	}
	
}
