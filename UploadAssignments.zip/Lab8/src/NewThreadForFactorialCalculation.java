
public class NewThreadForFactorialCalculation implements Runnable{
	@Override
	public void run(){
		for(int i=0;i<=5;i++){
			try {
				Thread.sleep(1100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				System.out.println("Factorial :"+FactorialOfANumber.factorial(NewThreadCreationForNumber.n));
			}
		}
	}
}
