
public class Date 
{
	int day,month,year;
	public void initDate()
	{
		day=0;month=0;year=0;
	}
	public void setDate(int dd,int mm,int yy)
	{
		day=dd;
		month=mm;
		year=yy;
	}
	public String dispDate()
	{
		return day+"/"+month+"/"+year;
	}
}
