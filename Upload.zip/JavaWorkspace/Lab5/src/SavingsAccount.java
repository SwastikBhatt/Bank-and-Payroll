
public class SavingsAccount extends Account
{
	private static final double minBalance=500;
	public SavingsAccount(long accNum,double balance,double amount)
	{
		this.accNum=accNum;
		this.balance=balance;
	}
	public void withdraw(double amount) throws InsufficientBalance
	{
		if(balance-amount<minBalance)
		{
			balance-=amount;
		}
		else
			throw new InsufficientBalance();
	}
}
