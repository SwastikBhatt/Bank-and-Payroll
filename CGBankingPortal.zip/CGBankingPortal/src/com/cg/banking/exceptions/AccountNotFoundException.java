package com.cg.banking.exceptions;

public class AccountNotFoundException extends RuntimeException{
	public AccountNotFoundException(int s){
		System.out.println("Your account "+s+" is not found");
	}
}
