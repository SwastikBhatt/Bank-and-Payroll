public class TestDateGetSetClientDemo 
{
	public static void main(String args[])
	{
		Date d1=new Date();
		d1.setDate(21);
		d1.setMonth(1);
		d1.setYear(2012);
		
		Date d2=new Date();
		d2.setDate(12);
		d2.setMonth(2);
		d2.setYear(2013);
		
		Date d3=new Date();
		d3.setDate(1);
		d3.setMonth(3);
		d3.setYear(2014);
		
		System.out.println("D1 date of joining "+d1.getDate()+"/"+d1.getMonth()+"/"+d1.getYear());
		System.out.println("D2 date of joining "+d2.getDate()+"/"+d2.getMonth()+"/"+d2.getYear());
		System.out.println("D3 date of joining "+d3.getDate()+"/"+d3.getMonth()+"/"+d3.getYear());
	}
}
