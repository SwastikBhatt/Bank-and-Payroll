import java.util.ArrayList;
import java.util.Scanner;


public class PerformStringOperations 
{
	public static void stringOperations(String s1,String s2)
	{
		ArrayList<String> a1=new ArrayList<String>();
		String ms="";
		for(int i=0;i<s1.length();i++)
		{
			if(i%2!=0)
				ms+=s1.charAt(i);
			else
				ms+=s2;
		}
		a1.add(ms);
		int index=s1.lastIndexOf(s2);
		if(checkRepeats(s1,s2)>1)
		{
			ms=s1.substring(0,index)+reverse(s2)+s1.substring(index+s2.length());
		}
		else
			ms=s1+s2;
	    a1.add(ms);
	    index=s1.indexOf(s2);
		if(checkRepeats(s1,s2)>1)
		{
			ms=s1.substring(0,index)+s1.substring(index+s2.length());
		}
		else
			ms=s1;
	    a1.add(ms);
	    String divide[]=stringDivision(s2);
	    ms=divide[0]+s1+divide[1];
	    a1.add(ms);
	    for(int i=0;i<s2.length();i++)
	    	s1=s1.replace(s2.charAt(i), '*');
	    a1.add(s1);
	    for(int i=0;i<a1.size();i++)
	    	System.out.println(a1.get(i)+" ");
	}
	public static String reverse(String s)
	{
		String ms="";
		for(int i=s.length()-1;i>=0;i--)
			ms+=s.charAt(i);
		return ms;
	}
	public static int checkRepeats(String s1,String s2)
	{
		s1+=" ";int c=0;
		String[] arr=new String[(s1.length()-s2.length()+1)];
	    for(int i=0;i<arr.length-1;i++)
		   arr[i]=s1.substring(i, i+s2.length());
	    for(int i=0;i<arr.length-1;i++)
	    {
	    	if(arr[i].equals(s2))
	    		c++;
	    }
	    return c;
	}
	public static String[] stringDivision(String s2)
	{
		String div[]=new String[2];
		if(s2.length()%2==0)
		{
			div[0]=s2.substring(0,s2.length()/2);
			div[1]=s2.substring(s2.length()/2);
		}
		else
		{
			div[0]=s2.substring(0,(s2.length()/2)+1);
			div[1]=s2.substring((s2.length()/2)+1);
		}
		return div;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Strings s1 and s2");
		String s1=sc.next();
		String s2=sc.next();
		stringOperations(s1,s2);
	}

}
