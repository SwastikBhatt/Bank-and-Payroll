
public class Medicine 
{
	String medName;
	String compName;
	long medPrice;
	public Medicine()
	{
		medName="";
		compName="";
		medPrice=0;
	}
	public Medicine(String medName,String compName,long medPrice)
	{
		this.medName=medName;
		this.compName=compName;
		this.medPrice=medPrice;
	}
	public void displayMedInfo()
	{
		System.out.println("Medicine Name = "+medName+"\nCompany Name = "+compName+"\nmedPrice = "+medPrice);
	}
}
