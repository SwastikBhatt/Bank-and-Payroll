package com.cg.eis.pl;
import java.util.Scanner;
import com.cg.eis.bean.Designation;
import com.cg.eis.bean.Employee;
import com.cg.eis.bean.Insurance;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeServiceImp;
public class EmployeeDetailsMain 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of Employees ");
		int noEmployees=sc.nextInt();
		EmployeeServiceImp employee = new EmployeeServiceImp(noEmployees);
		for(int i=0;i<noEmployees;i++)
		{
			System.out.println("Enter Employee ID ");
			long eId=sc.nextLong();
			System.out.println("Enter Name of Employee ");
			String eName=sc.next();
			System.out.println("Enter Salary ");
			double eSalary=sc.nextDouble();
			System.out.println("Enter Designation of employees ");
			Designation eDesignation=null;
			System.out.println("1:System Associate \n2:Programmer \n3:Manager"
					+ "\n4:Clerk");
			switch(sc.nextInt())
			{
			case 1:eDesignation=Designation.SystemAssociate;
				   break;
			case 2:eDesignation=Designation.Programmer;
			       break;
			case 3:eDesignation=Designation.Manager;
			       break;
			case 4:eDesignation=Designation.Clerk;
			       break;
			}
			Insurance eInsuranceScheme=employee.findEmployeeInsurance(eSalary,eDesignation);
			employee.addEmployeeDetails(i, eId, eName, eSalary, eDesignation,eInsuranceScheme);
		}
		for(int i=0;i<noEmployees;i++)
		{
			System.out.println(" "+employee.displayEmployeeDetails(i));
		}
	}

}
