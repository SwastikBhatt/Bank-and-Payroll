import java.util.Scanner;


public class TestEmpClient 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee ID");
		int eId=sc.nextInt();
		System.out.println("Enter Employee Name");
		String eName=sc.next();
		System.out.println("Enter Employee Salary");
		int eSalary=sc.nextInt();
		System.out.println("Enter Employee date of joining");
		int eDoj=sc.nextInt();
		System.out.println("Enter Employee Month of joining");
		int eMoj=sc.nextInt();
		System.out.println("Enter Employee Year of joining");
		int eYoj=sc.nextInt();
		System.out.println("Enter Employee City");
		String eCity=sc.next();
		System.out.println("Enter Employee State");
		String eState=sc.next();
		System.out.println("Enter Employee Country");
		String eCountry=sc.next();
		System.out.println("Enter Employee Landmark");
		String eLandmark=sc.next();
		System.out.println("Enter Employee Zipcode");
		long eZipcode=sc.nextLong();
		Date swastikDOJ=new Date(eDoj,eMoj,eYoj);
		Employee swastik=new Employee(eId,eName,eSalary,swastikDOJ);
		Address swastikAdd=new Address();
		swastikAdd.setCity(eCity);
		swastikAdd.setState(eState);
		swastikAdd.setCountry(eCountry);
		swastikAdd.setLandmark(eLandmark);
		swastikAdd.setZipcode(eZipcode);
		System.out.println(swastik.dispEmpInfo());
		System.out.println("Address :"+swastikAdd.getCity()+" "+swastikAdd.getState()
				+" "+swastikAdd.getCountry()+" "+swastikAdd.getLandmark()+" "+swastikAdd.getZipcode());
		System.out.println("Swastik Annual Salary ="+swastik.calcAnnualSalary());
		
	}
}
