import java.time.LocalDate;
import java.time.Period;
import java.util.*;
public class DateDuration 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		LocalDate cdate=java.time.LocalDate.now();
		System.out.println("Current Date : "+cdate);
		System.out.println("Enter date in dd-mm-yyyy format ");
		String s=sc.nextLine();
		s=s+" ";
		int dd=Integer.parseInt(s.substring(0,2));
		int mm=Integer.parseInt(s.substring(3,5));
		int yyyy=Integer.parseInt(s.substring(6,10));
		LocalDate udate=LocalDate.of(yyyy, mm, dd);
		System.out.println(udate);
		Period p=Period.between(cdate, udate);
		System.out.println("Difference is "+p.getYears()+" years "+p.getMonths()+" Months "+ p.getDays()+" days");
				
	}
}
