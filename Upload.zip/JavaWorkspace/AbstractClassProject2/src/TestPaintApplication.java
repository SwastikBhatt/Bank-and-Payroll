
public class TestPaintApplication 
{
	public static void main(String args[])
	{
		Circle sh1=new Circle(6,"Circle");
		Circle sh2=new Circle(3,"Circle");
		Shape sh3=new Circle(4,"Circle");
		Shape sh4=new Circle(2,"Sphere");
		sh1.drawShape();
		System.out.println("area of circle : "+sh1.calcArea());
		sh2.drawShape();
		System.out.println("area of circle : "+sh2.calcArea());
		sh3.drawShape();
		System.out.println("area of circle : "+sh3.calcArea());
		sh4.drawShape();
		System.out.println("area of Sphere : "+sh4.calcArea());
	}
}
