package com.cg.library.services;

import java.util.List;

import com.cg.library.beans.Book;
import com.cg.library.beans.Employee;
import com.cg.library.exceptions.BookNotFoundException;
import com.cg.library.exceptions.EmployeeNotFoundException;

public interface LibraryServices {
	Book acceptBookDetails(String bookName);
	Employee acceptEmployeeDetails(String firstName,String lastName);
	public Book issueBook(Book book)throws BookNotFoundException;
	public boolean returnBook(Book book)throws BookNotFoundException;
	public Book getBookDetails(int bookISBN);
	Employee getEmployeeDetails(int employeeId)throws EmployeeNotFoundException;
	public int fineCalculation(Book book);
	public List<Book> getAllBookDetails();
}
