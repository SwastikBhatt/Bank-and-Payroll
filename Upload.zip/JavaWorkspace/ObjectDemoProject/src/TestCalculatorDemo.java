
public class TestCalculatorDemo 
{
	int num1;
	int num2;
	int result;
	public TestCalculatorDemo()
	{
		
	}
	public TestCalculatorDemo(int num1,int num2)
	{
		this.num1=num1;
		this.num2=num2;
	}
	public int divide()
	{
		int numbers[]=new int[2];
		numbers[0]=num1;
		numbers[1]=num2;
		try 
		{
			result=numbers[0]/numbers[1];
		} 
		catch (ArithmeticException e) 
		{
			e.printStackTrace();
		}
		System.out.println("division done successfully");
		return result;
	}
	
}
