import java.util.*;
public class TestDatatypesDemo 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		byte b=sc.nextByte();
		System.out.println("b= "+b);
		

	}

}
