package com.cg.payroll.client;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotFoundException {
		PayrollServices services=new PayrollServicesImpl();
		Scanner sc=new Scanner(System.in);

		int associateId=services.acceptAssociateDetails("Swastik", "Bhattacharya", "swastik@gmail.com", "ABC", "A", "BV45323", 1200, 12000, 100, 1400, 132313, "SBI", "ACDS");
		System.out.println("Associate Id = "+associateId);
		int associateId2=services.acceptAssociateDetails("Saiyam", "Lunia", "saiyam@gmail.com", "ABC", "A", "BV45323", 1200, 12000, 100, 1400, 132313, "BSC", "ACDS");
		System.out.println("Associate Id = "+associateId2);
		System.out.println("Enter associate id to be searched");
		int associateId3=sc.nextInt();
		Associate associate = null;
		try {
			associate = services.getAssociateDetails(associateId3);
			System.out.println(associate);
		} catch (AssociateDetailsNotFoundException e) {
		}
		try {
			System.out.println("Gross salary is "+services.calculateGrossSalary(associateId3));
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
		try {
			System.out.println("Net salary is "+services.calculateNetSalary(associateId3));
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println(services.getAllAssociateDetails());
		
	}
}

