package com.cg.project.beans;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Test;

public class DateTesting {

	@Test
	public void testDateValidation(){
		Date date=new Date(21, 10, 2019);
		assertEquals(21, date.getIntday());
	}
	@Test
	public void testMonthValidation(){
		Date date=new Date(21, 10, 2019);
		assertEquals(10, date.getIntmonth());
	}
	@Test
	public void testYearValidation(){
		Date date=new Date(21, 10, 2019);
		assertEquals(2019, date.getIntyear());
	}
	
}
