package com.cg.banking.exceptions;

public class BankingServicesDownException extends RuntimeException{
	public BankingServicesDownException() {
		System.out.println("Banking services are down");
	}
}
