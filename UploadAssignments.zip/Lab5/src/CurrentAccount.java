
public class CurrentAccount extends Account
{
	private double overdraft;
	public CurrentAccount(long accNum,double balance,double amount,double overdraft)
	{
		this.accNum=accNum;
		this.balance=balance;
		this.overdraft=overdraft;
	}
	public void withdraw(double amount) throws OverdraftLimitExceeded
	{
		if(amount<=overdraft)
		{
			balance-=amount;
		}
		else
			throw new OverdraftLimitExceeded();
	}
}
