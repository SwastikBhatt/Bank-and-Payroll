package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String args[]) {
		int accNo;
		int pinNo;
		float amount;
		BankingServices bankingService= new BankingServicesImpl();
		Account c1=null;
		Account c2=null;
		c1=bankingService.openAccount("Savings", 2000);
		c1.setAccountStatus("Active");
		c2=bankingService.openAccount("Savings", 9000);
		c2.setAccountStatus("Active");
		System.out.println("Account details\n"+c1);
		System.out.println("Account details\n"+c2);
		Scanner sc=new Scanner(System.in);
		System.out.println("*********************WITHDRAWAL**************************");
		System.out.println("Enter account number from which money is to be withdrawn");
		accNo=sc.nextInt();
		System.out.println("Enter pin number of that account");
		pinNo=sc.nextInt();
		System.out.println("Enter amount of money to be withdrawn");
		amount=sc.nextInt();
		System.out.println(bankingService.withdrawAmount(accNo, amount, pinNo));
		System.out.println("Account details after withdrawal"+bankingService.getAccountDetails(accNo));
		System.out.println("*********************DEPOSIT**************************");
		System.out.println("Enter account number to which money is to be deposited");
		accNo=sc.nextInt();
		System.out.println("Enter amount of money to be deposited");
		amount=sc.nextInt();
		System.out.println(bankingService.depositAmount(accNo, amount));
		System.out.println("Account details after withdrawal"+bankingService.getAccountDetails(accNo));
		System.out.println("*********************FUND TRANSFER**************************");
		System.out.println("Enter account number to which money is to be deposited");
		accNo=sc.nextInt();
		System.out.println("Enter account number from which money is to be transferred");
		int accNo2=sc.nextInt();
		System.out.println("Enter pin number of that account");
		pinNo=sc.nextInt();
		System.out.println("Enter amount of money to be deposited");
		amount=sc.nextInt();
		boolean b=bankingService.fundTransfer(accNo, accNo2, amount, pinNo);
		if(b==true)
		{
			System.out.println("Account details after transfer"+bankingService.getAccountDetails(accNo));
			System.out.println(bankingService.getAccountDetails(accNo2));
		}
	}
}
