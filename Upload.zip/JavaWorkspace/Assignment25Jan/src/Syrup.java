
public class Syrup extends Medicine
{
	public void displayMedInfo()
	{
		System.out.println("Shake well before consumption");
		super.displayMedInfo();
	}

	public Syrup() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Syrup(String medName, String compName, long medPrice) {
		super(medName, compName, medPrice);
		// TODO Auto-generated constructor stub
	}
}
