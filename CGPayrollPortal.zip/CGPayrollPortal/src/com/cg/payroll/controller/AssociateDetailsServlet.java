package com.cg.payroll.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@WebServlet(urlPatterns= {"/AssociateDetailsServlet"},loadOnStartup=12)
public class AssociateDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PayrollServices services;
    @Override
	public void destroy() {
		services=null;
	}

	@Override
	public void init() throws ServletException {
		services=PayrollServicesImpl.getPayrollInstance();
	}

	public AssociateDetailsServlet() {

    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher requestDispatcher=null;
		int associateId=Integer.parseInt(request.getParameter("associateId"));
		Associate associate=null;
		try {
			associate = services.getAssociateDetails(associateId);
		} catch (AssociateDetailsNotFoundException e) {
		}
		if(associate==null) {
			requestDispatcher=request.getRequestDispatcher("associateDetails.jsp");
			request.setAttribute("error", "Associate ID or password is wrong");
			requestDispatcher.forward(request, response);
		}
		request.setAttribute("associate", associate);
		request.getRequestDispatcher("associateDetailsSuccess.jsp").forward(request, response);
	}

}
