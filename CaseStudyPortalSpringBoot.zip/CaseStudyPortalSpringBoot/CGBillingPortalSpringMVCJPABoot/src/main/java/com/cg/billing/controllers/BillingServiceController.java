package com.cg.billing.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Customer;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;

@Controller
public class BillingServiceController {
	@Autowired
	BillingServices billingServices;
	
	@RequestMapping("/registerCustomer")
	public ModelAndView registerAssociate(@Valid @ModelAttribute Customer customer) {
		customer = billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("registrationSuccessPage","customer",customer);
	}
	
	@RequestMapping("/customerDetails")
	public ModelAndView getAssociateDetails(@RequestParam int customerID)throws CustomerDetailsNotFoundException {
		Customer customer = billingServices.getCustomerDetails(customerID);
		return new ModelAndView("findCustomerDetailsPage","customer",customer);
	}

	@RequestMapping("/customerAllDetails")
	public ModelAndView getAllAssociateDetails()throws CustomerDetailsNotFoundException {
		List<Customer> customerList = billingServices.getAllCustomerDetails();
		return new ModelAndView("findAllCustomerDetailsPage","customerList",customerList);
	}
	
	@RequestMapping("/postpaidPlanSet")
	public ModelAndView getpostpaidPlanSet(@RequestParam int customerID,@RequestParam int planID)throws CustomerDetailsNotFoundException, PlanDetailsNotFoundException {
		PostpaidAccount account = billingServices.openPostpaidMobileAccount(customerID, planID);
		return new ModelAndView("postpaidSuccessPage","account",account);
	}

	@RequestMapping("/postpaidPlanGet")
	public ModelAndView getpostpaidPlanGet(@RequestParam int customerID,@RequestParam long mobileNo)throws CustomerDetailsNotFoundException, PlanDetailsNotFoundException, PostpaidAccountNotFoundException {
		PostpaidAccount account = billingServices.getPostPaidAccountDetails(customerID, mobileNo);
		return new ModelAndView("postpaidDetailsPage","account",account);
	}
	
	//calculateBill
	@RequestMapping("/calculateBill")
	public ModelAndView getCalculateBill(@RequestParam int customerID,@RequestParam long mobileNo,
			@RequestParam String billMonth,@RequestParam int noOfLocalSMS,
			@RequestParam int noOfStdSMS,@RequestParam int noOfLocalCalls,
			@RequestParam int noOfStdCalls,@RequestParam int internetDataUsageUnits)throws CustomerDetailsNotFoundException, PlanDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {
		Customer customer = billingServices.getCustomerDetails(customerID);
		double bill=billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits);
		return new ModelAndView("findBillAmountPage","bill",bill);
	}
	
}
