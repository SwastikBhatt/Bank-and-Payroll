
@SuppressWarnings("serial")
public class OverdraftLimitExceeded extends Exception
{
	public OverdraftLimitExceeded()
	{
		System.out.println("Overdraft Limit Exceeded");
	}
}