public class Person 
{
	String firstName,lastName;
	char gender;
	public Person()
	{
		firstName="";
		lastName="";
		gender='\0';
	}
	public Person(String firstName,String lastName,char gender)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
	}
	public String getFirstName()
	{
		return this.firstName;
	}
	public String getLastName()
	{
		return this.lastName;
	}
	public char getGender()
	{
		return this.gender;
	}
	public void setFirstName(String firstName)
	{
		this.firstName=firstName;
	}
	public void setLastName(String lastName)
	{
		this.lastName=lastName;
	}
	public void setGender(char gender)
	{
		this.gender=gender;
	}
}
