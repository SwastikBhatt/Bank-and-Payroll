package com.cg.eis.service;

import com.cg.eis.bean.Designation;
import com.cg.eis.bean.Insurance;

public interface EmployeeService 
{
	public abstract void addEmployeeDetails(int i,long eId,String eName,double eSalary,
			Designation eDesignation,Insurance eInsuranceScheme);
	public abstract Insurance findEmployeeInsurance(double eSalary,
			Designation eDesignation);
	public abstract String displayEmployeeDetails(int i);
}
