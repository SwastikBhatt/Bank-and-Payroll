package com.cg.banking.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


@WebServlet("/OpenAccountServlet")
public class OpenAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    BankingServices bankingServices;
    
	@Override
	public void destroy() {
		bankingServices=null;
	}

	@Override
	public void init() throws ServletException {
		bankingServices=BankingServicesImpl.getBanking();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher requestDispatcher=null;
		int accountBalance=Integer.parseInt(request.getParameter("accountBalance"));
		String accountType=request.getParameter("accountType");
		String accountStatus=request.getParameter("accountStatus");
		
		if(accountBalance==0||accountType==""||accountStatus=="") {
			requestDispatcher=request.getRequestDispatcher("openAccount.jsp");
			request.setAttribute("error", "Missing Information");
			requestDispatcher.forward(request, response);
		}
		else {
		Account account=bankingServices.openAccount(accountType,accountBalance,accountStatus);
		request.setAttribute("account", account);
		request.getRequestDispatcher("openAccountSuccess.jsp").forward(request, response);
		}
	}

}
