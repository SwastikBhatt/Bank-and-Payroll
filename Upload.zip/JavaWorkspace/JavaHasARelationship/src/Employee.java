public class Employee 
{
	private int empId;
	private String empName;
	private float empSalary;
	private Date empDOJ;
	public Employee()
	{
		empId=0;
		empName=null;
		empSalary=0.0F;
		empDOJ=new Date();
	}
	public Employee(int empId,String empName,float empSalary,Date empDOJ)
	{
		this.empId=empId;
		this.empName=empName;
		this.empSalary=empSalary;
		this.empDOJ=empDOJ;
	}
	public String dispEmpInfo()
	{
		return "[ID: "+empId+" Name: "+empName+" Salary: "+empSalary+"Date of Joining"+empDOJ.displayDate()+"]";
	}
	public float calcAnnualSalary()
	{
		return empSalary*12;
	}
}
