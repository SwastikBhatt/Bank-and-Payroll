class Calculator
{
	public int add(int num1,int num2)
	{
		return num1+num2;
	}
	public String add(String s1,String s2)
	{
		return s1+s2;
	}
	public int add(byte num1,byte num2)
	{
		return (num1+num2);
	}
	public int add(byte num1,byte num2,byte num3)
	{
		return num1+num2+num3;
	}
	public void add(float num1,float num2,float num3)
	{
		System.out.println(num1+num2+num3);
	}
}
public class TestCalculatorDemo 
{
	public static void main(String[] args)
	{
		Calculator ob=new Calculator();
		System.out.println(ob.add(40, 60));
		System.out.println(ob.add((byte)40, (byte)60));
		System.out.println(ob.add("Saiyam","Roshan"));
		System.out.println(ob.add((byte)40, (byte)60, (byte)23));
		ob.add(12.3f,13.98f,7.98f);
	}
}
