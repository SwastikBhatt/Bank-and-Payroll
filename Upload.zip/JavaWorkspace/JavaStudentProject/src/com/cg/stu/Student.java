package com.cg.stu;
import com.cg.bat.Batch;
public class Student 
{
	private int rollNo;
	private String studentName;
	private Batch stuBatch;
	public String dispStuInfo() 
	{
		return "Student [rollNo=" + rollNo + ", studentName=" + studentName
				+ ", stuBatchInfo=" + stuBatch.getBatchCode() +" "+stuBatch.getBatchName()
				+" "+stuBatch.getBatchTime()+" "+stuBatch.getFacultyName()+"]";
	}
	public Student(int rollNo, String studentName, Batch stuBatch)
	{
		super();
		this.rollNo = rollNo;
		this.studentName = studentName;
		this.stuBatch = stuBatch;
	}
	
	
}
