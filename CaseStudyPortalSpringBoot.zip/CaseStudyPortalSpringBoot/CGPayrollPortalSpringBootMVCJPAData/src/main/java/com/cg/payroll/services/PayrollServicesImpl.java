package com.cg.payroll.services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
@Component("payrollServices")
public class PayrollServicesImpl implements PayrollServices{
	@Autowired
	private AssociateDAO associateDao;
	
	@Override
	public Associate acceptAssociateDetails(Associate associate) {
		associate=associateDao.save(associate);
		return associate;
	}
	@Override
	public String toString() {
		return "PayrollServicesImpl [associateDao=" + associateDao + "]";
	}
	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=getAssociateDetails(associateId);
		return  (int) (12*calculateGrossSalary(associateId)+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf());
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		return associateDao.findById(associateId).orElseThrow(()->new AssociateDetailsNotFoundException("Associate Details not found"));
		
	}
	@Override
	public List<Associate> getAllAssociateDetails() {
		return associateDao.findAll();
	}
	@Override
	public int calculateGrossSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=getAssociateDetails(associateId);
		return (int) (associate.getSalary().getBasicSalary()+.3*associate.getSalary().getBasicSalary()*2+.25*associate.getSalary().getBasicSalary()+.2*associate.getSalary().getBasicSalary()+
				associate.getSalary().getCompanyPf()+associate.getSalary().getEpf());
	}
}
