package com.cg.library.services;

import java.time.Period;
import java.util.List;

import com.cg.library.beans.Book;
import com.cg.library.beans.Employee;
import com.cg.library.daoservices.BookDAO;
import com.cg.library.daoservices.BookDAOImpl;
import com.cg.library.daoservices.EmployeeDAO;
import com.cg.library.daoservices.EmployeeDAOImpl;
import com.cg.library.exceptions.BookNotFoundException;
import com.cg.library.exceptions.EmployeeNotFoundException;
import com.cg.library.util.LibraryUtil;
public class LibraryServicesImpl implements LibraryServices {
	private BookDAO bookDAO;
	private EmployeeDAO empDAO;
	public LibraryServicesImpl() {
		bookDAO=new BookDAOImpl();
		empDAO=new EmployeeDAOImpl();
	}
	public LibraryServicesImpl(BookDAO bookDAO) {
		this.bookDAO=bookDAO;
	}
	public Book issueBook(Book book) throws BookNotFoundException {
		return book;
	}
	public boolean returnBook(Book book) {
		if(book!=null)
			return true;
		else
			return false;
	}

	public int fineCalculation(Book book) {
		Period p=Period.between(book.getIssueDate(), book.getReturnDate());
		return p.getDays()*12;
	}
	@Override
	public Book acceptBookDetails(String bookName){
		Book book=new Book(bookName);
		book=bookDAO.save(book);
		return book;
	}
	@Override
	public Employee acceptEmployeeDetails(String firstName, String lastName) {
		Employee emp=new Employee(firstName, lastName, LibraryUtil.getEMPLOYEE_NUMBER());
		emp=empDAO.save(emp);
		return emp;
	}
	@Override
	public Employee getEmployeeDetails(int employeeId) throws EmployeeNotFoundException {
		Employee employee=empDAO.findOneEmp(employeeId);
		return employee;
	}
	@Override
	public Book getBookDetails(int bookISBN) {
		Book book=bookDAO.findOne( bookISBN);
		return book;
	}
	public List<Book> getAllBookDetails(){
		return bookDAO.findAll();
	}
}
