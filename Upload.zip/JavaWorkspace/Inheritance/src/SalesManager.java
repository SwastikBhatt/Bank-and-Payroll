
public class SalesManager extends WageEmp
{
	double saleAmount;
	public SalesManager(int empId, String empName,
			float empBasicSal,int noOfHours,double saleAmount)
	{
		this.empId=empId;
		this.empBasicSal=empBasicSal;
		this.noOfHours = noOfHours;
		this.empName=empName;
		this.saleAmount=saleAmount;
	}
	
	public String displaySalesManagerInfo() {
		return "SalesManager info ["+super.dispWageEmpInfo()+" sales Amount "
				+saleAmount+" Monthly Salary "+calcWageSaleManagerMonSal()
				+" Yearly Salary "+calcWageSaleManagerAnnualSal()+" ]";
	}

	public float calcWageSaleManagerMonSal()
	{
		return (float) (empBasicSal+(noOfHours*ratePerHours*20)+(.02*saleAmount));
	}
	public float calcWageSaleManagerAnnualSal()
	{
		return calcWageSaleManagerMonSal()*12;
	}
}
