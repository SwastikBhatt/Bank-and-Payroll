package com.cg.payroll.services;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssocialeDAOImpl;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class PayrollServicesImpl implements PayrollServices{
	private AssociateDAO associateDao;
	public PayrollServicesImpl() {
		associateDao=new AssocialeDAOImpl();
	}
	public PayrollServicesImpl(AssociateDAO associateDao) {
		this.associateDao=associateDao;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
		Associate associate= new Associate(yearlyInvestmentUnder8oC, firstName, lastName, department, designation, pancard, emailId, new BankDetails(accountNumber, bankName, ifscCode), new Salary(basicSalary,  epf, companyPf));
		associate=associateDao.save(associate);
		return associate.getAssociateId();
	}
	@Override
	public String toString() {
		return "PayrollServicesImpl [associateDao=" + associateDao + "]";
	}
	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=getAssociateDetails(associateId);
		return  (int) (12*calculateGrossSalary(associateId)+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf());
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate Details not found for "+associateId);
		return associate;
	}
	@Override
	public List<Associate> getAllAssociateDetails() {
		return associateDao.findAll();
	}
	@Override
	public int calculateGrossSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=getAssociateDetails(associateId);
		return (int) (associate.getSalary().getBasicSalary()+.3*associate.getSalary().getBasicSalary()*2+.25*associate.getSalary().getBasicSalary()+.2*associate.getSalary().getBasicSalary()+
				associate.getSalary().getCompanyPf()+associate.getSalary().getEpf());
	}
}
