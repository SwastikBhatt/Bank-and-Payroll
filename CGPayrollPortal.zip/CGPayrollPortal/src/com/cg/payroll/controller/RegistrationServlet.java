package com.cg.payroll.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@WebServlet(urlPatterns= {"/RegistrationServlet"},loadOnStartup=12)
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PayrollServices services;
    public RegistrationServlet() {
        super();

    }
	@Override
	public void destroy() {
		services=null;
	}
	@Override
	public void init() throws ServletException {
		services=PayrollServicesImpl.getPayrollInstance();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher requestDispatcher=null;
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String emailId=request.getParameter("emailId");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		String pancard=request.getParameter("pancard");
		int yearlyInvestmentUnder8oC=Integer.parseInt(request.getParameter("yearlyInvestmentUnder8oC"));
		int basicSalary=Integer.parseInt(request.getParameter("basicSalary"));
		int epf=Integer.parseInt(request.getParameter("epf"));
		int companyPf=Integer.parseInt(request.getParameter("companyPf"));
		int accountNo=Integer.parseInt(request.getParameter("accountNo"));
		String bankName=request.getParameter("bankName");
		String bankIfsc=request.getParameter("bankIfsc");
		if(firstName==""||lastName==""||emailId==""||department==""||designation==""||pancard==""||accountNo==0||bankName==""||bankIfsc=="")
		{
			requestDispatcher=request.getRequestDispatcher("associateRegistration.jsp");
			request.setAttribute("error", "Associate ID or password is wrong");
			requestDispatcher.forward(request, response);
		}
		int associateId=services.acceptAssociateDetails(new Associate(yearlyInvestmentUnder8oC, firstName, lastName, department, designation, pancard, emailId, new BankDetails(accountNo, bankName, bankIfsc), new Salary(basicSalary, epf, companyPf)));
		request.setAttribute("associateId", associateId);
		request.getRequestDispatcher("registrationSuccessPage.jsp").forward(request, response);
	}

}
