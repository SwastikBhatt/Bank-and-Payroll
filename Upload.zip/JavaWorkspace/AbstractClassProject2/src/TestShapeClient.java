import java.util.Scanner;


public class TestShapeClient 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		Shape shaps[]=new Shape[4];
		int choice;
		for(int i=0;i<shaps.length;i++)
		{
			System.out.println("Which Shapes do you want ");
			System.out.println("Enter 1:Circle \n2:Sphere \n3:Exit");
			choice=sc.nextInt();
			System.out.println("Enter radius");
			int rad=sc.nextInt();
			switch(choice)
			{
				case 1:shaps[i]=new Circle(rad,"Circle");
				case 2:shaps[i]=new Sphere(rad,"Sphere");
				case 3:System.exit(0);
				default:shaps[i]=new Circle(rad,"Circle");
			}
		}
		for(int i=0;i<shaps.length;i++)
		{
			shaps[i].drawShape();
			if(shaps[i] instanceof Circle)
			{
				System.out.println("********Sphere********");
				System.out.println("Area is= "+shaps[i].calcArea());
				System.out.println("Volume is "
				+((Sphere)shaps[i]).calcVolume());
			}
			else if(shaps[i] instanceof Circle)
			{
				System.out.println("********Sphere********");
				System.out.println("Area is "+shaps[i].calcArea());
				System.out.println("Circumference is "+((Circle)shaps[i]).calcCircumference());
			}
		}
	}
}
