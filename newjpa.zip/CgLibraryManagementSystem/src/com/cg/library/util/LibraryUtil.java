package com.cg.library.util;

import java.util.HashMap;

import com.cg.library.beans.Book;
import com.cg.library.beans.Employee;

public class LibraryUtil {
	public static HashMap<Integer,Book> issueBook=new HashMap<>();
	public static HashMap<Integer,Employee> employeeDetail=new HashMap<>();
	public static int BOOK_NUMBER=10000;
	private static int EMPLOYEE_NUMBER=100;
	public static int getEMPLOYEE_NUMBER() {
		return ++EMPLOYEE_NUMBER;
	}
	public static int getBOOK_NUMBER() {
		return ++BOOK_NUMBER;
	}
}
