public enum Seasons
{
	Summer,Rainy,Winter
}
