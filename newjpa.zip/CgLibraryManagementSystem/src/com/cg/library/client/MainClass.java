package com.cg.library.client;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

import com.cg.library.beans.Book;
import com.cg.library.beans.Employee;
import com.cg.library.daoservices.BookDAO;
import com.cg.library.daoservices.BookDAOImpl;
import com.cg.library.services.LibraryServices;
import com.cg.library.services.LibraryServicesImpl;
import com.cg.library.util.LibraryUtil;

public class MainClass {

	public static void main(String[] args) {
		LibraryServices services=new LibraryServicesImpl();
		System.out.println("Books available");
		Scanner sc=new Scanner(System.in);
		Book book1 = new Book("ABCD", 12345);
		System.out.println(book1.toString());
		Book book2 = new Book("EFGH", 12346);
		System.out.println(book2.toString());
		Book book3 = new Book("IJKL", 12347);
		System.out.println(book3.toString());
		Book book4 = new Book("MNOP", 12348);
		System.out.println(book4.toString());
		services.acceptBookDetails(book1.getBookName());
		services.acceptBookDetails(book2.getBookName());
		services.acceptBookDetails(book3.getBookName());
		services.acceptBookDetails(book4.getBookName());
		Employee emp=new Employee("Swastik", "Bhattacharya",LibraryUtil.getEMPLOYEE_NUMBER());
		System.out.println(emp.toString());
		while(true) {
			System.out.println("\n\nEnter a choice \n1:Withdraw book \n2:Deposit book \n3:Get book details \n4:Get all book Details");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:System.out.println("Enter date of submission");
						LocalDate cdate=java.time.LocalDate.now();
						System.out.println("Current Date : "+cdate);
						System.out.println("Enter date in dd-mm-yyyy format ");
						String s=sc.next();
						s=s+" ";
						int dd=Integer.parseInt(s.substring(0,2));
						int mm=Integer.parseInt(s.substring(3,5));
						int yyyy=Integer.parseInt(s.substring(6,10));
						LocalDate udate=LocalDate.of(yyyy, mm, dd);
						System.out.println(udate);
						Period p=Period.between(cdate, udate);
						BookDAO book=new BookDAOImpl();
						book.save(book1);
						book.save(book2);
						System.out.println(LibraryUtil.issueBook);
						break;
			case 2:LibraryUtil.issueBook.remove(10001);
						System.out.println(LibraryUtil.issueBook);
						break;
			case 3:System.out.println(services.getBookDetails(book1.getBookISBN()));
						break;
			case 4:System.out.println(services.getAllBookDetails());
						break;
			case 5:System.exit(0);
			default:System.out.println("You have entered a wrong choice");
			}

		}
	}
}
