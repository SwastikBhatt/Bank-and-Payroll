
public enum Gender 
{
	M,F,m,f
}
