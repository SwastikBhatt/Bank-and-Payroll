import java.util.Scanner;
public class ArrangeStringAscending 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter array size ");
		int n=sc.nextInt();
		String stringArray[]=new String[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter "+i+"th string");
			stringArray[i]=sc.next();
		}
		System.out.println("\n\nBefore Ascending ordering");
		for(int i=0;i<n;i++)
			System.out.print(stringArray[i]+"  ");
		String convertedArray[]=ascendingAndLowerUpper(stringArray);
		
		
		System.out.println("\n\nAfter Ascending ordering");
		for(int i=0;i<n;i++)
			System.out.print(convertedArray[i]+"  ");
	}
	public static String[] ascendingAndLowerUpper(String a[])
	{
		for(int i=0;i<a.length-1;i++)
		{
			for(int j=0;j<a.length-i-1;j++)
			{
				if(a[j].compareTo(a[j+1])>0)
				{
					String temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		for(int i=a.length-1;i>=a.length/2;i--)
			a[i]=a[i].toUpperCase();
		for(int i=0;i<a.length/2;i++)
			a[i]=a[i].toLowerCase();
		return a;
			
	}
}
