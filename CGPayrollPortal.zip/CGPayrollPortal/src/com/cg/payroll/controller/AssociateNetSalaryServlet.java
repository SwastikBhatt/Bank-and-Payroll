package com.cg.payroll.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@WebServlet(urlPatterns= {"/AssociateNetSalaryServlet"},loadOnStartup=12)
public class AssociateNetSalaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PayrollServices services;
    public AssociateNetSalaryServlet() {
        super();
    }
    @Override
	public void destroy() {
		services=null;
	}

	@Override
	public void init() throws ServletException {
		services=PayrollServicesImpl.getPayrollInstance();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher requestDispatcher=null;
		int associateId=Integer.parseInt(request.getParameter("associateId"));
		Associate associate=null;int gross=0;
		try {
			associate = services.getAssociateDetails(associateId);
		} catch (AssociateDetailsNotFoundException e) {
		}
		if(associate==null) {
			requestDispatcher=request.getRequestDispatcher("associateGrossSalary.jsp");
			request.setAttribute("error", "Associate ID or password is wrong");
			requestDispatcher.forward(request, response);
		}
		try {
			gross=services.calculateNetSalary(associateId);
		} catch (AssociateDetailsNotFoundException e) {
		}
		associate.getSalary().setNetSalary(gross);
		request.setAttribute("associate", associate);
		request.getRequestDispatcher("associateNetSalarySuccess.jsp").forward(request, response);
	}

}
