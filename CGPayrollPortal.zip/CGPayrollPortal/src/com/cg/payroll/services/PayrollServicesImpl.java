package com.cg.payroll.services;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssocialeDAOImpl;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class PayrollServicesImpl implements PayrollServices{
	private AssociateDAO associateDao;
	private static PayrollServices payrollServices;
	private PayrollServicesImpl() {
		associateDao=new AssocialeDAOImpl();
	}
	public static PayrollServices getPayrollInstance() {
		if(payrollServices==null)
			payrollServices=new PayrollServicesImpl();
		return payrollServices;
	}
	public PayrollServicesImpl(AssociateDAO associateDao) {
		this.associateDao=associateDao;
	}
	@Override
	public int acceptAssociateDetails(Associate associate) {
		associate=associateDao.save(associate);
		return associate.getAssociateId();
	}
	@Override
	public String toString() {
		return "PayrollServicesImpl [associateDao=" + associateDao + "]";
	}
	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=getAssociateDetails(associateId);
		return  (int) (12*calculateGrossSalary(associateId)+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf());
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDao.findOne(associateId);
		
		return associate;
	}
	@Override
	public List<Associate> getAllAssociateDetails() {
		return associateDao.findAll();
	}
	@Override
	public int calculateGrossSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=getAssociateDetails(associateId);
		return (int) (associate.getSalary().getBasicSalary()+.3*associate.getSalary().getBasicSalary()*2+.25*associate.getSalary().getBasicSalary()+.2*associate.getSalary().getBasicSalary()+
				associate.getSalary().getCompanyPf()+associate.getSalary().getEpf());
	}
}
