public class TestEmpClientDemo 
{
	public static void main(String args[])
	{
		Employee swastik=new Employee(123,"Swastik",60000.0f);
		WageEmp roshan=new WageEmp(124,"Roshan",70000.0f,5);
		SalesManager saiyam=new SalesManager(125,"Saiyam",80000.0f,6,100000);
		System.out.println(swastik.displayEmpInfo()+"\nMonthly Salary  "
				+swastik.calcEmpMonSal()+"\nYearly Salary  "
				+swastik.calcEmpAnnualSal());

		System.out.println(roshan.displayEmpInfo()+"\nMonthly Salary"
				+roshan.calcEmpMonSal()+"\nYearly Salary"
				+roshan.calcEmpAnnualSal());
		
		System.out.println(saiyam.displayEmpInfo()+"\nMonthly Salary"
				+saiyam.calcEmpMonSal()+"\nYearly Salary"
				+saiyam.calcEmpAnnualSal());
	}
}
