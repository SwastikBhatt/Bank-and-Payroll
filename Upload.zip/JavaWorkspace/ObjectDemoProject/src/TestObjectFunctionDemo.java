
public class TestObjectFunctionDemo 
{
	public static void main(String args[])
	{
		Employee e1=new Employee(333,"Swastik",4000f);
		Employee e2=new Employee(444,"Roshan",4000f);
		Employee e3=new Employee(444,"Saiyam",4000f);
		
		System.out.println(e1.toString());
		System.out.println(e2.toString());
		System.out.println(e3.toString());
		
		Integer i1=new Integer(40);
		Integer i2=new Integer(40);
		Integer i3=new Integer(40);
		
		System.out.println("******************equals********************");
		if(e1.equals(e2))
			System.out.println("We are same");
		else
			System.out.println("We are not the same");
		System.out.println("Hashcode of i1 ="+i1.hashCode());
		System.out.println("Hashcode of i2 ="+i2.hashCode());
		System.out.println("Hashcode of i3 ="+i3.hashCode());
		
		System.out.println("Hashcode of e1 ="+e1.hashCode());
		System.out.println("Hashcode of e2 ="+e2.hashCode());
		System.out.println("Hashcode of e3 ="+e3.hashCode());
		
	}

}

