package com.cg.library.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.library.beans.Book;
import com.cg.library.beans.Employee;
import com.cg.library.util.LibraryUtil;

public class EmployeeDAOImpl implements EmployeeDAO{

	public Employee save(Employee employee) {
		employee.setEmployeeId(LibraryUtil.getEMPLOYEE_NUMBER());
		LibraryUtil.employeeDetail.put(employee.getEmployeeId(),employee);
		return employee;
	}

	public Employee findOneEmp(int employeeId) {
		return LibraryUtil.employeeDetail.get(employeeId);
	}

	public List<Employee> findAll() {

		return new ArrayList<Employee>(LibraryUtil.employeeDetail.values());
	}

}
