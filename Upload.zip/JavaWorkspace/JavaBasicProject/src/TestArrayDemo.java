public class TestArrayDemo 
{
	public static void main(String[] args)
	{
		int marks[]=new int[5];
		marks[0]=90;
		marks[1]=80;
		marks[2]=91;
		marks[3]=67;
		marks[4]=78;
		for(int i=0;i<marks.length;i++)
			System.out.println("marks["+i+"]= "+marks[i]);
		System.out.println("**********2D***********");
		int A[][]=new int[3][2];
		A[0][0]=12;
		A[0][1]=32;
		A[1][0]=34;
		A[1][1]=45;
		A[2][0]=56;
		A[2][1]=67;
		for(int i=0;i<A.length;i++)
		{
			for(int j=0;j<A[0].length;j++)
				System.out.print(A[i][j]+"  ");
			System.out.println();
		}
	}
}
