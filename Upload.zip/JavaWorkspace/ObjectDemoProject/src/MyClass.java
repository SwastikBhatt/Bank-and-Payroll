import java.io.IOException;


public class MyClass 
{
	public void method1() throws IOException
	{
		System.out.println("Method 1 starts here");
		method2();
		System.out.println("Method 1 ends here ");
	}
	public void method2() throws IOException
	{
		System.out.println("Method 2 starts here");
		throw new IOException();
		
	}

}
