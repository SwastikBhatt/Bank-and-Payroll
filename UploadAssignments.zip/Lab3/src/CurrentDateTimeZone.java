import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Scanner;


public class CurrentDateTimeZone 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Zone as \nAmerica/New_York, \nEurope/London, \nAsia/Tokyo,"
				+ "\nUS/Pacific, \nAfrica/Cairo, \nAustralia/Sydney");
		String zone=sc.next();
		System.out.println("Zonal Date : "+java.time.LocalDateTime.now(ZoneId.of(zone)));
	}
}
