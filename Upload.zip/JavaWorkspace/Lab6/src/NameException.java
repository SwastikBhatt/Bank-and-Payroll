
@SuppressWarnings("serial")
public class NameException extends Exception
{
	public NameException()
	{
		System.out.println("First or last name is empty");
	}

}
