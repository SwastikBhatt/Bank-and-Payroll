package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDAOImpl implements TransactionDAO{
	public Transaction save(int accountNo,Transaction transaction) {
		transaction.setTransactionId(BankingDBUtil.getTRANSACTION_NUMBER());
		BankingDBUtil.customer.get(accountNo).getTransaction().put((long) transaction.getTransactionId(), transaction);
		return transaction;
	}
	public Transaction findOne(int accountNo,int transactionId) {
		return BankingDBUtil.customer.get(accountNo).getTransaction().get(transactionId);
	}
	public List<Transaction> findAll(int accountNo) {
		return new ArrayList<Transaction>(BankingDBUtil.customer.get(accountNo).getTransaction().values());
	}
}



