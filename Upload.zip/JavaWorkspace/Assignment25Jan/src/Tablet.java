
public class Tablet extends Medicine
{
	
	public Tablet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Tablet(String medName, String compName, long medPrice) {
		super(medName, compName, medPrice);
		// TODO Auto-generated constructor stub
	}

	public void displayMedInfo()
	{
		System.out.println("Keep in a cool place");
		super.displayMedInfo();
	}
}
