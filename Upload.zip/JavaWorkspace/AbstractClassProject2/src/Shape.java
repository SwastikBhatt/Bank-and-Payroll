
public abstract class Shape 
{
	int rad;
	String shapeType;
	public Shape(String shapeType,int rad)
	{
		this.shapeType=shapeType;
		this.rad=rad;
	}
	public void drawShape()
	{
		System.out.println(shapeType+" Draw with red colour");
	}
	public abstract float calcArea();
}
