import java.util.Scanner;
public class GenerateMedicineInformation 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of medicines ");
		int n=sc.nextInt();
		Medicine med[]=new Medicine[n];int c=0;
		System.out.println("Enter medicines as (number of tablet,number of syrup,number of ointment ");
		int tab=sc.nextInt();
		int syr=sc.nextInt();
		int oin=sc.nextInt();
		for(int i=1;i<=tab;i++)
		{
			System.out.println("Enter tablet name");
			String tabName=sc.next();

			System.out.println("Enter Company name");
			String comName=sc.next();

			System.out.println("Enter tablet price");
			Long tabPrice=sc.nextLong();
			med[c]=new Tablet(tabName,comName,tabPrice);
			c++;
		}
		for(int i=1;i<=syr;i++)
		{
			System.out.println("Enter Syrup name");
			String syrName=sc.next();

			System.out.println("Enter Company name");
			String comName=sc.next();

			System.out.println("Enter Syrup price");
			Long syrPrice=sc.nextLong();
			med[c]=new Syrup(syrName,comName,syrPrice);
			c++;
		}
		for(int i=1;i<=oin;i++)
		{
			System.out.println("Enter Ointment name");
			String oinName=sc.next();

			System.out.println("Enter Company name");
			String comName=sc.next();

			System.out.println("Enter Ointment price");
			Long oinPrice=sc.nextLong();
			med[c]=new Ointment(oinName,comName,oinPrice);
			c++;
		}
		for(int i=0;i<n;i++)
			med[i].displayMedInfo();
	}
}
