package com.cg.library.exceptions;

public class BookNotFoundException extends Exception{
	public BookNotFoundException(String s) {
		System.out.println("Book of ISBN no: "+s+" is not found");
	}
}
