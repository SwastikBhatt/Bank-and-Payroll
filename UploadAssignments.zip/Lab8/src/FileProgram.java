import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class FileProgram {
	public static boolean threadFileCopy(String fileFrom,String fileTo){
		FileInputStream fin=null;
		FileOutputStream fout=null;
		try {
			fin=new FileInputStream(fileFrom);
			fout=new FileOutputStream(fileTo);
			Thread fileCopyThread=new CopyDataThread(fin, fout);
			fileCopyThread.start();
			fileCopyThread.join();
			return true;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				fin.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				fout.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
}
