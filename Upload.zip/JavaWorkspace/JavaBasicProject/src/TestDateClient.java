
public class TestDateClient 
{
	public static void main(String[] args)
	{
		Date swastikDOJ=null;
		swastikDOJ=new Date();
		swastikDOJ.initDate();
		swastikDOJ.setDate(16,01,2019);
		System.out.println("Swastik DOJ is "+swastikDOJ.dispDate());
	}
}
