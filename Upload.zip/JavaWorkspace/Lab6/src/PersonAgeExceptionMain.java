
public class PersonAgeExceptionMain 
{
	public static void main(String args[]) throws AgeException
	{
		PersonAgeException swastik=new PersonAgeException("Swastik",21);
		System.out.println("Name="+swastik.getName()+"\nAge="+swastik.getAge());
	}

}
