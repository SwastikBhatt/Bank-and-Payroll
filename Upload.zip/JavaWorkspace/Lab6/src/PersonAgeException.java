
public class PersonAgeException 
{
	String name;
	float age;
	public PersonAgeException()
	{
		name="";
		age=0.0F;
	}
	public PersonAgeException(String name, float age) throws AgeException
	{
		super();
		this.name = name;
		if(age>15)
			this.age = age;
		else
			throw new AgeException();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) throws AgeException 
	{
		if(age>15)
		this.age = age;
		else
			throw new AgeException();
	}
}
