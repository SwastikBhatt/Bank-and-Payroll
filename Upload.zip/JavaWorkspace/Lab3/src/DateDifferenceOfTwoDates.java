import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;
public class DateDifferenceOfTwoDates 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter date in dd-mm-yyyy format");
		String s=sc.nextLine();
		s=s+" ";
		int dd=Integer.parseInt(s.substring(0,2));
		int mm=Integer.parseInt(s.substring(3,5));
		int yyyy=Integer.parseInt(s.substring(6,10));
		LocalDate date1=LocalDate.of(yyyy, mm, dd);
		System.out.println(date1);
		System.out.println("Enter date in dd-mm-yyyy format");
		s=sc.nextLine();
		s=s+" ";
		dd=Integer.parseInt(s.substring(0,2));
		mm=Integer.parseInt(s.substring(3,5));
		yyyy=Integer.parseInt(s.substring(6,10));
		LocalDate date2=LocalDate.of(yyyy, mm, dd);
		System.out.println(date2);
		Period p=Period.between(date1, date2);
		System.out.println("Difference is "+p.getYears()+" years "+p.getMonths()+" Months "+ p.getDays()+" days");
	}
}
