package com.cg.library.daoservices;

import java.util.ArrayList;
import java.util.List;
import com.cg.library.beans.Book;
import com.cg.library.util.LibraryUtil;

public class BookDAOImpl implements BookDAO{

	@Override
	public Book save(Book book) {
		book.setBookISBN(LibraryUtil.getBOOK_NUMBER());
		LibraryUtil.issueBook.put(book.getBookISBN(), book);
		return book;
	}

	@Override
	public Book findOne(int bookISBN) {
		return LibraryUtil.issueBook.get(bookISBN);
	}

	@Override
	public boolean update(Book book) {
		if(LibraryUtil.issueBook.containsKey(book.getBookISBN())) {
			LibraryUtil.issueBook.put(book.getBookISBN(), book);
			return true;
		}
		return false;
	}

	@Override
	public List<Book> findAll() {
		return new ArrayList<Book>(LibraryUtil.issueBook.values());
	}
	
}
