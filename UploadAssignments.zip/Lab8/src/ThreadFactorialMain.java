
public class ThreadFactorialMain {
	public static void main(String args[]){
		Thread t1=new Thread(new NewThreadCreationForNumber());
		Thread t2=new Thread(new NewThreadForFactorialCalculation());
		t1.start();
		t2.start();
	}
}
