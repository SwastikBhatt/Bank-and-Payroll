
public class Sphere extends Circle
{
	public Sphere(int rad,String shapeType)
	{
		super(rad,shapeType);
	}

	@Override
	public float calcArea() 
	{
		return (float) (4*Math.PI*rad*rad);
	}
	public float calcVolume()
	{
		return (float) ((4/3)*Math.PI*rad*rad*rad);
	}
}
