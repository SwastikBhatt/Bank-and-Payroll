
public class MainClass {
	public static void main(String args[]){
		FileProgram.threadFileCopy("d:\\source.txt", "d:\\destination.txt");
	}
}
