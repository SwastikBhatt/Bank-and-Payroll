package com.cg.banking.exceptions;

public class AccountBlockedException extends RuntimeException{
	public AccountBlockedException(int s) {
		System.out.println("Your account "+s+" has been blocked");
	}
}
