package com.cg.banking.exceptions;

public class InsufficientAmountException extends RuntimeException{
	public InsufficientAmountException(){
		System.out.println("Amount is Insufficient");
	}
}
