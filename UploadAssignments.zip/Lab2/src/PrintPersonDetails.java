import java.util.Scanner;
public class PrintPersonDetails 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Full name");
		String name=sc.nextLine();
		System.out.println("Enter gender");
		char gender=(sc.nextLine()).charAt(0);
		System.out.println("Enter age");
		int age=sc.nextInt();
		System.out.println("Enter weight");
		double weight=sc.nextDouble();
		String firstName=name.substring(0,name.indexOf(" "));
		String lastName=name.substring(name.indexOf(" "));
		System.out.println("Person Details:"+"\n____________\nFirst Name: "+firstName+
				"\nLast Name:"+lastName+"\nGender: "+gender+"\nAge: "+age+"\nWeight: "+weight);
	}
}
