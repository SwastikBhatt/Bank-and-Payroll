package com.cg.library.exceptions;

public class EmployeeNotFoundException extends Exception {
	public EmployeeNotFoundException() {
		System.out.println("Employee details not found");
	}
}
