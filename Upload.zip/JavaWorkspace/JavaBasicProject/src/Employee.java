
public class Employee {

	int eId;
	String eName;
	float eSalary;
	char eGender;
	public Employee()
	{
		eId=0;
		eName="";
		eSalary=0;
		eGender='\0';
	}
	public Employee(int id1,String name1,float salary1,char gender1)
	{
		eId=id1;
		eName=name1;
		eSalary=salary1;
		eGender=gender1;
	}
	public void displayEmployee()
	{
		System.out.println("Person Details:"+"\n____________\nFirst Name: "+eName+
				"\nEmployee ID: "+eId+"\nSalary: "+eSalary+"\nGender: "+eGender);
	}

}
