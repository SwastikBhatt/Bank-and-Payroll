
public class ThreadUsingTimer implements Runnable{
	@Override
	public void run(){
		for(int i=5;i>=0;i--){
			System.out.println("Timer Value : "+i);
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
