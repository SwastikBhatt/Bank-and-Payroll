
public class TestInterfaceDemo 
{
	public static void main(String args[])
	{
		Printable pp=new Person("Swastik","ADCDSDA");
		System.out.println(pp.print());
		System.out.println(((Person) pp).sayHi());
	}

}
