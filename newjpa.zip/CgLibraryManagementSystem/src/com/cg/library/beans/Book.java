package com.cg.library.beans;

import java.time.LocalDate;
import java.util.HashMap;


public class Book {
	private String bookName;
	private int bookISBN;
	LocalDate issueDate;
	LocalDate returnDate;
	Employee employee;
	BookTransaction bookTransaction;
	public BookTransaction getBookTransaction() {
		return bookTransaction;
	}

	public void setBookTransaction(BookTransaction bookTransaction) {
		this.bookTransaction = bookTransaction;
	}

	public HashMap<Long, Book> getTransaction() {
		return transaction;
	}

	public void setTransaction(HashMap<Long, Book> transaction) {
		this.transaction = transaction;
	}
	private HashMap<Long,Book> transaction=new HashMap();
	public Book() {
		super();
	}
	
	@Override
	public String toString() {
		return "Book [bookName=" + bookName + ", bookISBN=" + bookISBN  + "]";
	}
	public Book(String bookName, int bookISBN, LocalDate issueDate, LocalDate returnDate, Employee employee,
			HashMap<Long, Book> transaction) {
		super();
		this.bookName = bookName;
		this.bookISBN = bookISBN;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
		this.employee = employee;
		this.transaction = transaction;
	}
	public Book(String bookName, int bookISBN) {
		super();
		this.bookName = bookName;
		this.bookISBN = bookISBN;
	}
	public Book(String bookName) {
		this.bookName=bookName;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + bookISBN;
		result = prime * result + ((bookName == null) ? 0 : bookName.hashCode());
		result = prime * result + ((employee == null) ? 0 : employee.hashCode());
		result = prime * result + ((issueDate == null) ? 0 : issueDate.hashCode());
		result = prime * result + ((returnDate == null) ? 0 : returnDate.hashCode());
		result = prime * result + ((transaction == null) ? 0 : transaction.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (bookISBN != other.bookISBN)
			return false;
		if (bookName == null) {
			if (other.bookName != null)
				return false;
		} else if (!bookName.equals(other.bookName))
			return false;
		if (employee == null) {
			if (other.employee != null)
				return false;
		} else if (!employee.equals(other.employee))
			return false;
		if (issueDate == null) {
			if (other.issueDate != null)
				return false;
		} else if (!issueDate.equals(other.issueDate))
			return false;
		if (returnDate == null) {
			if (other.returnDate != null)
				return false;
		} else if (!returnDate.equals(other.returnDate))
			return false;
		if (transaction == null) {
			if (other.transaction != null)
				return false;
		} else if (!transaction.equals(other.transaction))
			return false;
		return true;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public int getBookISBN() {
		return bookISBN;
	}
	public void setBookISBN(int bookISBN) {
		this.bookISBN = bookISBN;
	}
	public LocalDate getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
}
