package com.cg.billing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgBillingPortalSpringMvcjpaBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgBillingPortalSpringMvcjpaBootApplication.class, args);
	}

}
