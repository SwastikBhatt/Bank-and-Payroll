
public class PersonV2Main {
	public static void main(String[] args) 
	{
		PersonV2 obj=new PersonV2("Swastik","Bhattacharya",'M',25717938);
		System.out.println("First Name= "+obj.getFirstName());
		System.out.println("Last Name= "+obj.getLastName());
		System.out.println("Gender= "+obj.getGender()); 
		System.out.println("Phone Number= "+obj.getphNumber());	
	}
}
