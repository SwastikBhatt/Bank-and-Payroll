package com.cg.banking.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.Session;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServicesImpl;

public class TransactionDAOImpl implements TransactionDAO{
	EntityManagerFactory entityManagerfactory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Transaction save(int accountNo, Transaction transaction) {
		EntityManager entityManager=entityManagerfactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
		return transaction;
	}

	@Override
	public Transaction findOne(int accountNo, int transactionId) {

		return entityManagerfactory.createEntityManager().find(Transaction.class, transactionId);
	}

	@Override
	public List<Transaction> findAll(int accountNo) {
		String hql="from Transaction t where t.account.accountNo = :accountId";
		Query query=entityManagerfactory.createEntityManager().createQuery(hql); 
		query.setParameter("accountId", accountNo);
		return query.getResultList();
		//return entityManagerfactory.createEntityManager().createQuery("from Transaction a where a.accountNo=accountNo", Transaction.class).getResultList();
	}
	
}



