class Parent
{
	int i=90;
	public void showMsg()
	{
		System.out.println("In Parent showMsg "+i);
	}
	public static void getCount()
	{
		System.out.println("In Parent get Count");
	}
}
class Child extends Parent
{
	int i=80;
	public void showMsg()
	{
		System.out.println("In Child showMsg");
	}
	public static void getCount()
	{
		System.out.println("in Child get Count");
	}
}
public class TestAnnotationDemo 
{
	public static void main(String args[])
	{
		Parent p1=new Parent();
		System.out.println(p1.i);
		p1.showMsg();
		p1.getCount();
		
		Child c1=new Child();
		System.out.println(c1.i);
		c1.showMsg();
		c1.getCount();
		
		Parent c3=new Child();
		System.out.println(c3.i);
		c3.showMsg();
		c3.getCount();
	}

}
