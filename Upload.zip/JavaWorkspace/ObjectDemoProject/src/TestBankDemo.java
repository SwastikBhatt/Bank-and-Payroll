import java.util.Scanner;

class Account
{
	private int accountNo;
	private int currentBalance;
	
	public Account(int currentBalance) 
	{
		super();
		this.currentBalance = currentBalance;
	}
	public void withdraw(int withdraw) throws LowBalanceException
	{
		if(currentBalance>=withdraw)
		{
			currentBalance-=withdraw;
			System.out.println("You can withdraw : "+withdraw);
			System.out.println("After withdraw balance is "+currentBalance);
		}
		else
			throw new LowBalanceException("Less balance in your account");
	}
}
public class TestBankDemo 
{
	public static void main(String args[]) throws LowBalanceException
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("What is your current balance");
		int cBalance=sc.nextInt();
		Account swastikAcc=new Account(cBalance);
		System.out.println("ENter withdraw amount");
		int withAmount=sc.nextInt();
		try 
		{
			swastikAcc.withdraw(withAmount);
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}
