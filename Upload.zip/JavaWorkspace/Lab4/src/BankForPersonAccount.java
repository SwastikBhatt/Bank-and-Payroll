import java.util.Scanner;
public class BankForPersonAccount {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Person smith=new Person();
		Person kathy=new Person();
		long accNum=(long) (Math.random()*10000);
		Account accountSmith=new Account();
		Account accountKathy=new Account();
		accountSmith.setAccHolder(smith);
		accountSmith.setBalance(2000);
		accountSmith.setAccNum(accNum);
		smith.setName("Smith");
		smith.setAge(21);
		accountSmith.deposit(2000);
		System.out.println(accountSmith.toString());
		accNum=(long) (Math.random()*10000);
		accountKathy.setAccHolder(kathy);
		accountKathy.setBalance(3000);
		accountKathy.setAccNum(accNum);
		kathy.setName("Kathy");
		kathy.setAge(21);
		try {
			accountKathy.withdraw(3000);
		} catch (InsufficientBalance e) {
			// TODO Auto-generated catch block
		} catch (OverdraftLimitExceeded e) {
			// TODO Auto-generated catch block
		}
		System.out.println(accountKathy.toString());
	}

}
