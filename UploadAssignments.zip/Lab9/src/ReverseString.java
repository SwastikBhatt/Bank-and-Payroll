
public class ReverseString {
	public static String revString(String s){
		String ms="";
		for(int i=s.length()-1;i>=0;i--)
			ms+=s.charAt(i);
		return ms;
	}
}
