
public class PersonMain 
{
	public static void main(String[] args) 
	{
		Person obj=new Person("Swastik","Bhattacharya",'M');
		System.out.println("First Name= "+obj.getFirstName());
		System.out.println("Last Name= "+obj.getLastName());
		System.out.println("Gender= "+obj.getGender());

	}
}
