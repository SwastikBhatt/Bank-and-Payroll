package com.cg.eis.bean;
import com.cg.eis.exception.EmployeeException;
public class Employee 
{
	long eId;
	String eName;
	double eSalary;
	Designation eDesignation;
	Insurance eInsuranceScheme;
	
	public Employee(long eId, String eName, double eSalary,
			Designation eDesignation, Insurance eInsuranceScheme) throws EmployeeException {
		super();
		this.eId = eId;
		this.eName = eName;
		if(eSalary<3000)
			throw new EmployeeException();
		this.eSalary = eSalary;	
		this.eDesignation = eDesignation;
		this.eInsuranceScheme = eInsuranceScheme;
	}
	public long geteId() {
		return eId;
	}
	public void seteId(long eId) {
		this.eId = eId;
	}
	@Override
	public String toString() {
		return "Employee [eId=" + eId + ", eName=" + eName + ", eSalary="
				+ eSalary + ", eDesignation=" + eDesignation
				+ ", eInsuranceScheme=" + eInsuranceScheme + "]";
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public double geteSalary() {
		return eSalary;
	}
	public void seteSalary(double eSalary) {
		this.eSalary = eSalary;
	}
	public Designation geteDesignation() {
		return eDesignation;
	}
	public void seteDesignation(Designation eDesignation) {
		this.eDesignation = eDesignation;
	}
	public Insurance geteInsuranceScheme() {
		return eInsuranceScheme;
	}
	public void seteInsuranceScheme(Insurance eInsuranceScheme) {
		this.eInsuranceScheme = eInsuranceScheme;
	}
	
}
