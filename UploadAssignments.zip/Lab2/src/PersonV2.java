public class PersonV2 
{
	String firstName,lastName;
	char gender;
	long phNumber;
	public PersonV2()
	{
		firstName="";
		lastName="";
		gender='\0';
		phNumber=0;
	}
	public PersonV2(String firstName,String lastName,char gender,long phNumber)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
		this.phNumber=phNumber;
	}
	public String getFirstName()
	{
		return this.firstName;
	}
	public String getLastName()
	{
		return this.lastName;
	}
	public char getGender()
	{
		return this.gender;
	}
	public long getphNumber()
	{
		return this.phNumber;
	}
	public void setFirstName(String firstName)
	{
		this.firstName=firstName;
	}
	public void setLastName(String lastName)
	{
		this.lastName=lastName;
	}
	public void setGender(char gender)
	{
		this.gender=gender;
	}
	public void setphNumber(long phNumber)
	{
		this.phNumber=phNumber;
	}
}

