
public class SalesManager extends WageEmp
{
	double saleAmount;
	public SalesManager(int empId, String empName,
			float empBasicSal,int noOfHours,double saleAmount)
	{
		this.empId=empId;
		this.empBasicSal=empBasicSal;
		this.noOfHours = noOfHours;
		this.empName=empName;
		this.saleAmount=saleAmount;
	}
	
	public String displayEmpInfo() {
		return "SalesManager info ["+super.displayEmpInfo()+" sales Amount "
				+saleAmount+" Monthly Salary "+calcEmpMonSal()
				+" Yearly Salary "+calcEmpAnnualSal()+" ]";
	}

	public float calcEmpMonSal()
	{
		return (float) (empBasicSal+(noOfHours*ratePerHours*20)+(.02*saleAmount));
	}
	public float calcEmpAnnualSal()
	{
		return calcEmpMonSal()*12;
	}
}
