package com.cg.billing.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billing.beans.Address;
import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.daoservices.BillDAO;
import com.cg.billing.daoservices.CustomerDAO;
import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PostpaidAccountDAO;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	private BillDAO billDao;
	@Autowired
	private CustomerDAO customerDao;
	@Autowired
	private PlanDAO planDao;
	@Autowired
	private PostpaidAccountDAO postpaidAccountDao;
	
	@Override
	public List<Plan> getPlanAllDetails() {
		return planDao.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		customer=customerDao.save(customer);
		return customer;
	}

	@Override
	public PostpaidAccount openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		Customer customer=customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid"));
		Plan plan=planDao.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("Plan ID is invalid"));
		PostpaidAccount account=new PostpaidAccount(plan, customer);
		account=postpaidAccountDao.save(account);
		return account;
	}

	@Override
	public double generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {
		
		float internetDataUsageAmount=0,localCallAmount=0,stdCallAmount=0,localSMSAmount=0,stdSMSAmount=0,totalBillAmount=0,stateGST, centralGST;
		Customer customer= customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid"));
		Map<Long, PostpaidAccount> postpaidMap=customer.getPostpaidAccounts();
		PostpaidAccount acc=postpaidMap.get(mobileNo);
		Plan p=acc.getPlan();
		if(internetDataUsageUnits-p.getFreeInternetDataUsageUnits()>0)
			internetDataUsageAmount=(internetDataUsageUnits-p.getFreeInternetDataUsageUnits())*p.getInternetDataUsageRate();
		
		if(noOfLocalCalls-p.getFreeLocalCalls()>0)
			localCallAmount=(noOfLocalCalls-p.getFreeLocalCalls())*p.getFreeLocalCalls();
		
		if(noOfStdCalls-p.getFreeStdCalls()>0)
			stdCallAmount=(noOfStdCalls-p.getFreeStdCalls())*p.getStdCallRate();
		
		if(noOfLocalSMS-p.getFreeLocalSMS()>0)
			localSMSAmount=(noOfLocalSMS-p.getFreeLocalSMS())*p.getFreeLocalSMS();
		
		if(noOfStdSMS-p.getFreeLocalSMS()>0)
			stdSMSAmount=(noOfStdSMS-p.getFreeStdSMS())*p.getFreeStdSMS();
		
		totalBillAmount=internetDataUsageAmount+localCallAmount+stdCallAmount+localSMSAmount+stdSMSAmount;
		stateGST=(float) (.09*totalBillAmount);
		centralGST=(float) (.09*totalBillAmount);
		totalBillAmount+=(stateGST+centralGST);
		Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, stateGST, centralGST);
		billDao.save(bill);
		return totalBillAmount;
	}

	@Override
	public Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		Customer customer= customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid"));
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		List<Customer> allCustomer= customerDao.findAll();
		return allCustomer;
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer= customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid"));
		return customer.getPostpaidAccounts().get(mobileNo);
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException {
		Customer customer=customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid"));
		Map<Long, PostpaidAccount> postpaidCustomer=customer.getPostpaidAccounts();
		return new ArrayList<PostpaidAccount>(postpaidCustomer.values());
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException {
		PostpaidAccount customer=getPostPaidAccountDetails(customerID,mobileNo);
		Map<Integer, Bill> bills=customer.getBills();
		for (Bill bill : bills.values()) {
			if(bill.getBillMonth().equals(billMonth))
				return bill;
		}
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		PostpaidAccount account=postpaidAccountDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid"));
		return new ArrayList<Bill>(account.getBills().values());
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer=customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid"));
		PostpaidAccount p=customer.getPostpaidAccounts().get(mobileNo);
		p.setPlan(planDao.findById(planID).orElseThrow(()->new PostpaidAccountNotFoundException("PostPaid Account not found")));
		postpaidAccountDao.save(p);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		PostpaidAccount account=getPostPaidAccountDetails(customerID, mobileNo);
		postpaidAccountDao.delete(account);
		return true;
	}

	@Override
	public boolean removeCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		Customer customer=customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid"));
		for (PostpaidAccount postpaid : customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid")).getPostpaidAccounts().values()) {
			postpaidAccountDao.delete(postpaid);
		}
		
		customerDao.delete(customer);
		return false;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		return getPostPaidAccountDetails(customerID, mobileNo).getPlan();
	}

}
