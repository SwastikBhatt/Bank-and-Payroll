package com.cg.library.daoservices;

import java.util.List;

import com.cg.library.beans.Employee;


public interface EmployeeDAO {
	public Employee save(Employee employee);
	public Employee findOneEmp(int employeeId);
	List<Employee>findAll();
}
