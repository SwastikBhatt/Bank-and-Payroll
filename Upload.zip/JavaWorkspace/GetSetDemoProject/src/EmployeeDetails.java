
public class EmployeeDetails 
{
	public static void main(String args[])
	{
		Employee swastik=new Employee();
		swastik.seteName("Swastik Bhattacharya");
		swastik.seteSalary(10000);
		swastik.seteGender(Gender.M);
		swastik.seteId(123);
		
		Employee pritam=new Employee();
		pritam.seteName("Pritam Chakroborty");
		pritam.seteSalary(10000);
		pritam.seteGender(Gender.M);
		pritam.seteId(124);
		
		Employee roshan=new Employee();
		roshan.seteName("Roshan Jha");
		roshan.seteSalary(10000);
		roshan.seteGender(Gender.M);
		roshan.seteId(125);
		
		System.out.println("Employee Details [eId: "+swastik.geteId()+" Name: "+swastik.geteName()+
				" Salary "+swastik.geteSalary()+" Gender "+swastik.geteGender());

		System.out.println("Employee Details [eId: "+pritam.geteId()+" Name: "+pritam.geteName()+
				" Salary "+pritam.geteSalary()+" Gender "+pritam.geteGender());

		System.out.println("Employee Details [eId: "+roshan.geteId()+" Name: "+roshan.geteName()+
				" Salary "+roshan.geteSalary()+" Gender "+roshan.geteGender());
		
	}
}
