function calcInterest() {
	var p = 1000;
	var n = 1;
	var r = 10;
	var ci =(p * (Math.pow((1 + r/100) , n)))-p;
	document.getElementById("comp_intr").innerHTML="Compound Interest is :"+ci
}