import java.util.ArrayList;
import java.util.Scanner;


public class RemoveArrayList 
{
	public static ArrayList<String> removeElements(ArrayList<String> l1,ArrayList<String> l2)
	{
		l1.removeAll(l2);
		return l1;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of elements of list 1");
		int n=sc.nextInt();
		ArrayList<String> list1=new ArrayList<String>();
		for(int i=0;i<n;i++)
			list1.add(sc.next());
		System.out.println("Enter number of elements of list 2");
		n=sc.nextInt();
		ArrayList<String> list2=new ArrayList<String>();
		for(int i=0;i<n;i++)
			list2.add(sc.next());
		ArrayList<String> list3=removeElements(list1,list2);
		for(int i=0;i<list3.size();i++)
			System.out.println(list3.get(i));
	}
}
