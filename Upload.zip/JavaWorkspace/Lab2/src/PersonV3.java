enum Gender
{
	Undefined, M,F
}
public class PersonV3 
{
	String firstName,lastName;
	Gender gender;
	long phNumber;
	public PersonV3()
	{
		firstName="";
		lastName="";
		gender=Gender.Undefined;
		phNumber=0;
	}
	public PersonV3(String firstName,String lastName,Gender gender,long phNumber)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
		this.phNumber=phNumber;
	}
	public String getFirstName()
	{
		return this.firstName;
	}
	public String getLastName()
	{
		return this.lastName;
	}
	public Gender getGender()
	{
		return this.gender;
	}
	public long getphNumber()
	{
		return this.phNumber;
	}
	public void setFirstName(String firstName)
	{
		this.firstName=firstName;
	}
	public void setLastName(String lastName)
	{
		this.lastName=lastName;
	}
	public void setGender(Gender gender)
	{
		this.gender=gender;
	}
	public void setphNumber(long phNumber)
	{
		this.phNumber=phNumber;
	}
}
