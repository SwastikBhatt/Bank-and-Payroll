
public class TestSwitchDemo 
{
	public static void main(String[] args)
	{
		char color='R';
		switch(color)
		{
		case 'B':System.out.println("Blue");break;
		case 'R':System.out.println("Red");break;
		case 'G':System.out.println("Green");break;
		case 'Y':System.out.println("Yellow");break;
		default:System.out.println("No color defined ");
		}
	}
}
