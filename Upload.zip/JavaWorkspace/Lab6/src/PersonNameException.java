public class PersonNameException 
{
	String firstName,lastName;
	char gender;
	public PersonNameException()
	{
		firstName="";
		lastName="";
		gender='\0';
	}
	public PersonNameException(String firstName,String lastName,char gender) throws NameException
	{
		if(firstName.isEmpty()==false)
			this.firstName=firstName;
		else
			throw new NameException();
		if(lastName.isEmpty()==false)
			this.lastName=lastName;
		else
			throw new NameException();
		this.gender=gender;
	}
	public String getFirstName()
	{
		return this.firstName;
	}
	public String getLastName()
	{
		return this.lastName;
	}
	public char getGender()
	{
		return this.gender;
	}
	public void setFirstName(String firstName) throws NameException
	{
		if(firstName.isEmpty()==false)
			this.firstName=firstName;
		else
			throw new NameException();
	}
	public void setLastName(String lastName) throws NameException
	{
		if(lastName.isEmpty()==false)
			this.lastName=lastName;
		else
			throw new NameException();
	}
	public void setGender(char gender)
	{
		this.gender=gender;
	}
}
