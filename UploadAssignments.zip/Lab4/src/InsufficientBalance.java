
public class InsufficientBalance extends Exception
{
	public InsufficientBalance()
	{
		System.out.println("Insufficient Balance");
	}
}
