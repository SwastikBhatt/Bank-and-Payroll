
public class PersonNameExceptionMain 
{
	public static void main(String[] args) throws NameException 
	{
		PersonNameException obj=new PersonNameException("Swastik","Bhattacharya",'M');
		System.out.println("First Name= "+obj.getFirstName());
		System.out.println("Last Name= "+obj.getLastName());
		System.out.println("Gender= "+obj.getGender());

	}
}
