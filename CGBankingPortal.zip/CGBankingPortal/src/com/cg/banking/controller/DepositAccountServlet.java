package com.cg.banking.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/DepositAccountServlet")
public class DepositAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BankingServices bankingServices;
	@Override
	public void destroy() {
		bankingServices=null;
	}

	@Override
	public void init() throws ServletException {
		bankingServices=BankingServicesImpl.getBanking();
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher requestDispatcher=null;
		int accountNo=Integer.parseInt(request.getParameter("accountNo"));
		int amount=Integer.parseInt(request.getParameter("amount"));
		Account account=bankingServices.getAccountDetails(accountNo);
		if(account==null) {
			requestDispatcher=request.getRequestDispatcher("depositAccount.jsp");
			request.setAttribute("error", "Missing Information");
			requestDispatcher.forward(request, response);
		}
		else {
		account.setAccountBalance(bankingServices.depositAmount(accountNo, amount));
		request.setAttribute("account", account);
		request.getRequestDispatcher("depositAccountSuccess.jsp").forward(request, response);
		}
	}

}
