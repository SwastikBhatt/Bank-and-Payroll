import com.cg.bat.Batch;
import com.cg.stu.Student;
public class TestStudentDemo 
{
	public static void main(String args[])
	{
		Batch javaBat=new Batch();
		javaBat.setBatchCode("JEE001");
		javaBat.setBatchName("Java Full Stack 16th Jan HWD");
		javaBat.setFacultyName("Anjulata Tembhare");
		javaBat.setBatchTime("8:30 A.M to 6:00 P.M");
		Batch dotNet=new Batch();
		dotNet.setBatchCode("DotNet001");
		dotNet.setBatchName("Java Full Stack 16th Jan DotNet");
		dotNet.setFacultyName("Shetal Patil");
		dotNet.setBatchTime("9:00 A.M to 6:00 P.M");		
		Student javaStu1=new Student(444,"Swastik Bhattacharya",javaBat);
		Student javaStu2=new Student(445,"Saiyam Lunia",javaBat);
		Student javaStu3=new Student(446,"Pritam Chakroborty",dotNet);
		System.out.println(javaStu1.dispStuInfo());
		System.out.println(javaStu2.dispStuInfo());
		System.out.println(javaStu3.dispStuInfo());
	}
}
