package com.cg.banking.daoservices;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.banking.beans.Account;
public class AccountDAOImpl implements AccountDAO{
	EntityManagerFactory entityManagerfactory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Account save(Account account) {
		account.setPinNo((int)(Math.random()*1000));
		EntityManager entityManager=entityManagerfactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}

	@Override
	public boolean update(Account account) {
		EntityManager entityManager=entityManagerfactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return false;
	}

	@Override
	public Account findOne(int accountNo) {
		return entityManagerfactory.createEntityManager().find(Account.class, accountNo);
	}

	@Override
	public List<Account> findAll() {
		return entityManagerfactory.createEntityManager().createQuery("from Account a", Account.class).getResultList();
	}
		
}
