package com.cg.banking.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component("bankingServices")
public class BankingServicesImpl implements BankingServices{
	@Autowired
	private AccountDAO accObj;
	@Autowired
	private TransactionDAO transData;
	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		account.setPinNo((int)(Math.random()*10000));
		account=accObj.save(account);
		return account;
	}

	@Override
	public float depositAmount(int accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account customer=null;
		customer=accObj.findById(accountNo).orElseThrow(()->new AccountNotFoundException(accountNo));
		if(customer.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException(accountNo);
		customer.setAccountBalance(customer.getAccountBalance()+amount);
		transData.save(new Transaction(amount, "Deposit",customer));
		this.accObj.save(customer);
		return customer.getAccountBalance();
	}

	@Override
	public float withdrawAmount(int accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account customer=null;
		customer=accObj.findById(accountNo).orElseThrow(()->new AccountNotFoundException(accountNo));
		if(customer.getPinNo()!=pinNumber)
		throw new InvalidPinNumberException();
		else if(customer.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException(accountNo);
		else if(customer.getAccountBalance()-amount<500)
			throw new InsufficientAmountException();
		customer.setAccountBalance(customer.getAccountBalance()-amount);
		transData.save(new Transaction(amount, "Withdraw",customer));
		this.accObj.save(customer);
		return customer.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(int accountNoTo, int accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerTo=null,customerFrom=null;
		customerTo=accObj.findById(accountNoTo).orElseThrow(()->new AccountNotFoundException(accountNoTo));
		customerFrom=accObj.findById(accountNoFrom).orElseThrow(()->new AccountNotFoundException(accountNoFrom));
		if(customerTo==null)
			throw new AccountNotFoundException(accountNoTo);
		else if(customerFrom.getPinNo()!=pinNumber)
			throw new InvalidPinNumberException();
		else if(customerTo.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException(accountNoTo);
		else if(customerFrom.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException(accountNoFrom);
		else
		{
			customerTo.setAccountBalance(customerTo.getAccountBalance()+transferAmount);
			transData.save(new Transaction(transferAmount, "Deposit",customerTo));
			this.accObj.save(customerTo);
			customerFrom.setAccountBalance(customerFrom.getAccountBalance()-transferAmount);
			transData.save(new Transaction(transferAmount, "Withdraw",customerFrom));
			this.accObj.save(customerFrom);
			return true;
		}
	}

	@Override
	public Account getAccountDetails(int accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=accObj.findById(accountNo).orElseThrow(()->new AccountNotFoundException(accountNo));
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		List<Account> allDetails=accObj.findAll();
		return allDetails;
	}

	
	  @Override 
	public List<Transaction> getAccountAllTransaction(int accountNo)
	  throws BankingServicesDownException, AccountNotFoundException {
		  List<Transaction> tranList=transData.findAll();
		  List<Transaction> tranListAccount=new ArrayList<Transaction>();
		  for (Transaction transaction : tranList) {
			if(transaction.getAccount().getAccountNo()==accountNo)
				tranListAccount.add(transaction);
		}
		return tranListAccount;
	}

	@Override
	public String accountStatus(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account customer=null;
		customer=accObj.findById(accountNo).orElseThrow(()->new AccountNotFoundException(accountNo));
		if(customer==null)
			throw new AccountNotFoundException(accountNo);
		else if(customer.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException(accountNo);
		else
			return "Active";
	}

}
