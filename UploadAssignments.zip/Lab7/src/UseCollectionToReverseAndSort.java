import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class UseCollectionToReverseAndSort 
{
	public static int[] getSorted(int a[])
	{
		int copy=0,rev;
		ArrayList<Integer> a1=new ArrayList<Integer>();
		for(int i=0;i<a.length;i++)
		{
			copy=a[i];rev=0;
			while(copy>0)
			{
				int dg=copy%10;
				rev=rev*10+dg;
				copy/=10;
			}
			a1.add(rev);
		}
		Collections.sort(a1);
		for(int i=0;i<a.length;i++)
		{
			a[i]=a1.get(i);
		}
		return a;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Array size");
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Before Sorting");
		for(int i=0;i<arr.length;i++)
			System.out.println(arr[i]+" ");
		int sortedReversed[]=getSorted(arr);
		System.out.println("After Sorting");
		for(int i=0;i<sortedReversed.length;i++)
			System.out.println(sortedReversed[i]+" ");
	}
}
