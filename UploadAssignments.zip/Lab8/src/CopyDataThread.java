import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class CopyDataThread extends Thread{
	FileInputStream fin;
	FileOutputStream fout;
	public CopyDataThread(FileInputStream fin, FileOutputStream fout) {
		super();
		this.fin = fin;
		this.fout = fout;
	}
	public void run(){
		int count=0;
		int c=0;
		try{
			while((c=fin.read())!=-1){
				fout.write(c);
				count++;
				if(count>=10){
					System.out.println("10 characters copied");
					count=1;
					Thread.sleep(5000);
				}
			}
		}catch(IOException e){
			e.printStackTrace();
		}catch(InterruptedException e){
			e.printStackTrace();
		}
	}

}
