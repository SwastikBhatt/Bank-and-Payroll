import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class ProductNameSorting {
	public static String[] getSorted(String a[])
	{
		ArrayList<String> a1=new ArrayList<String>();
		for(int i=0;i<a.length;i++)
		{
			a1.add(a[i]);
		}
		Collections.sort(a1);
		for(int i=0;i<a.length;i++)
		{
			a[i]=a1.get(i);
		}
		return a;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Array size");
		int n=sc.nextInt();
		String arr[]=new String[n];
		System.out.println("Enter product names");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.next();
		}
		System.out.println("Before Sorting");
		for(int i=0;i<arr.length;i++)
			System.out.println(arr[i]+" ");
		String sortedReversed[]=getSorted(arr);
		System.out.println("After Sorting");
		for(int i=0;i<sortedReversed.length;i++)
			System.out.println(sortedReversed[i]+" ");
	}
}
