import java.util.Scanner;
public class EmployeeInformation 
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of employees");
		int n=sc.nextInt();
		Employee emps[]=new Employee[n];
		
		for(int i=0;i<emps.length;i++)
		{
			System.out.println("Enter Full name");
			String name=sc.next();
		
			
		
			System.out.println("Employee ID");
			int id=sc.nextInt();
			
			System.out.println("Enter salary");
			float sal=sc.nextFloat();
			
			System.out.println("Enter gender");
			char gender=(sc.next()).charAt(0);
			emps[i]=new Employee(id,name,sal,gender);
		}
		for(int i=0;i<n;i++)
			emps[i].displayEmployee();
	}
}
