import java.util.Scanner;

public class CheckValidUsername
{
	public static boolean isValid(String s)
	{
		if(s.length()>=12 && s.endsWith("_job"))
			return true;
		return false;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Username to be checked");
		String userName=sc.next();
		boolean b=isValid(userName);
		if(b==true)
			System.out.println("Valid UserName");
		else
			System.out.println("Invalid UserName");
	}
}
