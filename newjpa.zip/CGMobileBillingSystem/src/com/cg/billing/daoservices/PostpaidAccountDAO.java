package com.cg.billing.daoservices;

import java.util.List;
import com.cg.billing.beans.PostpaidAccount;

public interface PostpaidAccountDAO {
	PostpaidAccount save(PostpaidAccount postpaidAccount);
	PostpaidAccount update(PostpaidAccount postpaidAccount);
	PostpaidAccount findOne(long mobileNo);
	List<PostpaidAccount> findAll();
}
