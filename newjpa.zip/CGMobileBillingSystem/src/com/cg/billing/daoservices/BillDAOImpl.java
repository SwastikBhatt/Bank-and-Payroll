package com.cg.billing.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.billing.beans.Bill;

public class BillDAOImpl implements BillDAO {
	EntityManagerFactory entityManagerfactory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Bill save(Bill bill) {
		EntityManager entityManager=entityManagerfactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(bill);
		entityManager.getTransaction().commit();
		entityManager.close();
		return bill;
	}

	@Override
	public boolean update(Bill bill) {
		EntityManager entityManager=entityManagerfactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(bill);
		entityManager.getTransaction().commit();
		entityManager.close();
		return false;
	}

	@Override
	public Bill findOne(int billId) {
		return entityManagerfactory.createEntityManager().find(Bill.class, billId);
	}

	@Override
	public List<Bill> findAll() {
		return entityManagerfactory.createEntityManager().createQuery("from Bill b", Bill.class).getResultList();
	}

}
