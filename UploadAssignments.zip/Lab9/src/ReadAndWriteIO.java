import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ReadAndWriteIO {
	public static void main(String args[]) throws IOException{
		String s1="";
		String s2="";
		int c=0;
		FileInputStream fin;FileOutputStream fout;
		try {
			fin = new FileInputStream("d:\\source.txt");
			while((c=fin.read())!=-1)
				s1+=Character.toString((char) c);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fout = new FileOutputStream("d:\\source.txt");
			s2=ReverseString.revString(s1);
			for(int i=0;i<s2.length();i++)
				fout.write(s2.charAt(i));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("File copied");
	}
}
