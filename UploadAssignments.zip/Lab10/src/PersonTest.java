import static org.junit.Assert.*;

import org.junit.Test;


public class PersonTest {

	@Test
	public void testGetFirstName(){
		Person person = new Person("Swastik", "Bhattacharya", 'M');
		assertEquals("Swastik", person.getFirstName());
	}
	@Test
	public void testGetLastName(){
		Person person = new Person("Swastik", "Bhattacharya", 'M');
		assertEquals("Bhattacharya", person.getLastName());
	}
	@Test
	public void testGetGender(){
		Person person = new Person("Swastik", "Bhattacharya", 'M');
		assertEquals('M', person.getGender());
	}
	@Test
	public void testToString(){
		Person person = new Person("Swastik", "Bhattacharya", 'M');
		String expected=person.toString();
		assertEquals(person.toString(),expected );
	}
}
