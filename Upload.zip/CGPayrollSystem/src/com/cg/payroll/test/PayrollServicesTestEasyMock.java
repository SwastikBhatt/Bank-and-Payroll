package com.cg.payroll.test;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;


public class PayrollServicesTestEasyMock {
	private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDAO;
	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDAO=EasyMock.mock(AssociateDAO.class);
		payrollServices=new PayrollServicesImpl(mockAssociateDAO);
	}
	@Before
	public void setUpMockTestData() {
		Associate associate1=new Associate(101, 78000, "Swastik", "Bhattacharya", "Training", "A", "DAS315", "swastik@capgemini.com", new BankDetails(12345, "CITI", "12321"),new Salary(30000, 1800, 1800));
		Associate associate2=new Associate(102, 78000, "Saiyam", "Lunia", "Training", "A", "D6F315", "saiyam@capgemini.com", new BankDetails(84368, "CITI", "12321"),new Salary(30000, 1800, 1800));
		Associate associate3=new Associate(78000, "Roshan", "Bhattacharya", "Training", "A", "GDIEW72", "rjah@capgemini.com", new BankDetails(12345, "CITI", "12321"),new Salary(30000, 1800, 1800));
		ArrayList<Associate> associateList=new ArrayList<Associate>();
		associateList.add(associate1);
		associateList.add(associate2);
		
		EasyMock.expect(mockAssociateDAO.save(associate3)).andReturn(associate3);
		
		EasyMock.expect(mockAssociateDAO.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDAO.findOne(102)).andReturn(associate2);
		EasyMock.expect(mockAssociateDAO.findOne(123)).andReturn(null);
		EasyMock.expect(mockAssociateDAO.findAll()).andReturn(associateList);
		EasyMock.expect(mockAssociateDAO);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateId()throws AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(1234);
		EasyMock.verify(mockAssociateDAO.findOne(1234));
	}
	@Test
	public void testGetAssociateDataForValidAssociateId()throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(101, 78000, "Swastik", "Bhattacharya", "Training", "A", "DAS315", "swastik@capgemini.com", new BankDetails(12345, "CITI", "12321"),new Salary(30000, 1800, 1800));
		Associate actualAssociate=payrollServices.getAssociateDetails(102);
		Assert.assertEquals(expectedAssociate,actualAssociate);
		EasyMock.verify(mockAssociateDAO.findOne(101));
	}
	@After
	public void tearDownTestMockData() {
		EasyMock.resetToDefault(mockAssociateDAO);
	}
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDAO=null;
		payrollServices=null;
	}
}
