public class EmpClient 
{
	public static void main(String args[])
	{
		Employee e1=null;
		e1=new Employee(333,"Swastik",3000.0f);
		System.out.println(e1.displayEmpInfo());
		System.out.println(e1.calcEmpMonSal());
		System.out.println(e1.calcEmpAnnualSal());
		Employee e2=null;
		e2=new WageEmp(333,"Ram",3000.0f,5);
		System.out.println(e2.displayEmpInfo());
		System.out.println(e2.calcEmpMonSal());
		System.out.println(e2.calcEmpAnnualSal());
		Employee e3=null;
		e3=new WageEmp(333,"Shyam",3000.0f,8);
		System.out.println(e3.displayEmpInfo());
		System.out.println(e3.calcEmpMonSal());
		System.out.println(e3.calcEmpAnnualSal());
	}

}
