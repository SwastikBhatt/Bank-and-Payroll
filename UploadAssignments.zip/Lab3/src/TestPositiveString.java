import java.util.Scanner;
public class TestPositiveString 
{
	public static boolean positiveString(String s)
	{
		for(int i=0;i<s.length()-1;i++)
		{
			if(s.charAt(i)>s.charAt(i+1))
				return false;
		}
		return true;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String");
		String s=sc.next();
		boolean b=positiveString(s);
		if(b==true)
			System.out.println(s+" is a valid positive string");
		else
			System.out.println(s+" is not a valid positive string");
	}
}
